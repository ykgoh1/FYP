"""
app.py - Neuro-Trap Flask Analyst Dashboard
Module 5: Professional cybersecurity dashboard with charts, real-time feel,
          threat map, ML scores, IoC management, MISP PDF export, and Rules Dashboard.

CHANGES v2.1:
  1. MISP export → PDF (via reportlab) instead of JSON
  2. YARA/Suricata Rules → full rules dashboard tab
  3. Telnet CMD capture fix (binary/protocol stripping)
  4. Overview charts → clickable, show detail breakdown modal
  5. Top stat cards → ML details real-time (avg score, top threat IPs)
  6. IoC Export → choose-and-download dashboard modal
"""

from flask import Flask, render_template_string, request, jsonify, send_file
import sqlite3
import csv
import io
import json
import logging
from datetime import datetime

from behaviour_ml  import run_ml_analysis
from ioc_extractor import run_extraction
from misp_mock     import export_approved_iocs

DB_PATH = "neuro_trap.db"
app     = Flask(__name__)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [DASHBOARD] %(message)s")
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Neuro-Trap | Threat Intelligence Platform</title>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
:root {
  --bg:#030b12;--bg2:#050f1a;--panel:#071520;--border:#0d2d45;--border2:#0a3d5c;
  --cyan:#00d4ff;--cyan2:#00ffcc;--red:#ff2d55;--orange:#ff6b2b;
  --yellow:#ffd60a;--green:#00ff88;--muted:#3a6880;--text:#c8e8f5;--text2:#6ba3be;
  --font:'Rajdhani',sans-serif;--mono:'Share Tech Mono',monospace;
}
*{box-sizing:border-box;margin:0;padding:0;}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--font);overflow-x:hidden;}
body::before{content:'';position:fixed;inset:0;
  background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,212,255,.015) 2px,rgba(0,212,255,.015) 4px);
  pointer-events:none;z-index:1000;}

/* TOPBAR */
.topbar{display:flex;align-items:center;gap:16px;padding:0 20px;height:58px;
  background:rgba(5,15,26,.95);border-bottom:1px solid var(--border2);
  position:sticky;top:0;z-index:500;backdrop-filter:blur(10px);overflow:hidden;width:100%;}
.logo{display:flex;align-items:center;gap:10px;font-family:var(--mono);font-size:1.1rem;
  color:var(--cyan);letter-spacing:.15em;text-transform:uppercase;}
.logo-icon{width:32px;height:32px;border:2px solid var(--cyan);border-radius:50%;
  display:flex;align-items:center;justify-content:center;font-size:.9rem;color:var(--cyan);
  box-shadow:0 0 12px rgba(0,212,255,.4);animation:pulse 2s ease-in-out infinite;}
@keyframes pulse{0%,100%{box-shadow:0 0 12px rgba(0,212,255,.4);}50%{box-shadow:0 0 24px rgba(0,212,255,.8);}}
.status-bar{margin-left:auto;display:flex;align-items:center;gap:20px;font-size:.78rem;font-family:var(--mono);}
.status-item{display:flex;align-items:center;gap:6px;color:var(--text2);}
.dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);animation:blink 1.5s ease-in-out infinite;}
.dot.red{background:var(--red);box-shadow:0 0 8px var(--red);}
@keyframes blink{0%,100%{opacity:1;}50%{opacity:.3;}}
.time-display{font-family:var(--mono);font-size:.85rem;color:var(--cyan);letter-spacing:.1em;}

/* LAYOUT */
.layout{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - 58px);width:100%;overflow:hidden;}

/* SIDEBAR */
.sidebar{background:var(--bg2);border-right:1px solid var(--border);
  padding:20px 0;display:flex;flex-direction:column;gap:4px;overflow-y:auto;overflow-x:hidden;min-width:0;}
.sidebar-section{padding:8px 20px 4px;font-size:.65rem;font-family:var(--mono);
  color:var(--muted);letter-spacing:.15em;text-transform:uppercase;margin-top:8px;}
.nav-item{display:flex;align-items:center;gap:10px;padding:10px 20px;cursor:pointer;
  font-size:.9rem;font-weight:600;color:var(--text2);border-left:3px solid transparent;
  transition:all .2s;letter-spacing:.05em;}
.nav-item:hover{background:rgba(0,212,255,.05);color:var(--cyan);border-left-color:var(--cyan);}
.nav-item.active{background:rgba(0,212,255,.08);color:var(--cyan);border-left-color:var(--cyan);}
.nav-icon{font-size:1rem;width:20px;text-align:center;}
.nav-badge{margin-left:auto;background:var(--red);color:#fff;font-size:.65rem;padding:2px 6px;border-radius:10px;font-family:var(--mono);}
.nav-badge.orange{background:var(--orange);}
.sidebar-bottom{margin-top:auto;padding:16px 20px;border-top:1px solid var(--border);}
.threat-level-label{font-size:.7rem;font-family:var(--mono);color:var(--text2);text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px;}
.threat-bar{height:6px;background:var(--border);border-radius:3px;overflow:hidden;}
.threat-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--green),var(--yellow),var(--orange),var(--red));width:0%;transition:width .8s ease;}
.threat-pct{font-size:.65rem;font-family:var(--mono);color:var(--muted);margin-top:6px;}

/* MAIN */
.main{overflow-y:auto;overflow-x:hidden;padding:20px;display:flex;flex-direction:column;gap:16px;min-width:0;width:100%;}

/* STAT CARDS - Enhanced with ML details */
.stats-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;width:100%;}
.stat-card{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:14px 16px;
  position:relative;overflow:hidden;transition:border-color .2s;cursor:pointer;}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;}
.stat-card.cyan::before{background:linear-gradient(90deg,transparent,var(--cyan),transparent);}
.stat-card.red::before{background:linear-gradient(90deg,transparent,var(--red),transparent);}
.stat-card.orange::before{background:linear-gradient(90deg,transparent,var(--orange),transparent);}
.stat-card.green::before{background:linear-gradient(90deg,transparent,var(--green),transparent);}
.stat-card.yellow::before{background:linear-gradient(90deg,transparent,var(--yellow),transparent);}
.stat-card:hover{border-color:var(--border2);}
.stat-label{font-size:.62rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.12em;margin-bottom:6px;}
.stat-value{font-size:2rem;font-weight:700;font-family:var(--mono);line-height:1;}
.stat-card.cyan   .stat-value{color:var(--cyan);}
.stat-card.red    .stat-value{color:var(--red);}
.stat-card.orange .stat-value{color:var(--orange);}
.stat-card.green  .stat-value{color:var(--green);}
.stat-card.yellow .stat-value{color:var(--yellow);}
.stat-sub{font-size:.65rem;color:var(--muted);margin-top:3px;font-family:var(--mono);}
/* NEW: ML mini-detail under stat */
.stat-ml-detail{font-size:.6rem;font-family:var(--mono);margin-top:6px;padding-top:6px;border-top:1px solid var(--border);color:var(--text2);line-height:1.7;}
.stat-ml-detail span{color:var(--cyan2);}

/* PANELS */
.panel{display:none;flex-direction:column;gap:20px;}
.panel.active{display:flex;}

/* SECTION HEADER */
.section-header{display:flex;align-items:center;gap:12px;font-size:.7rem;font-family:var(--mono);
  color:var(--cyan);text-transform:uppercase;letter-spacing:.15em;padding-bottom:10px;border-bottom:1px solid var(--border);}
.section-header::before{content:'';width:3px;height:16px;background:linear-gradient(180deg,var(--cyan),var(--cyan2));border-radius:2px;}

/* CHART ROW */
.chart-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;width:100%;}
.chart-box{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:16px;min-width:0;overflow:hidden;}
.chart-box.clickable{cursor:pointer;transition:border-color .2s;}
.chart-box.clickable:hover{border-color:var(--cyan2);}
.chart-title{font-size:.7rem;font-family:var(--mono);color:var(--text2);text-transform:uppercase;letter-spacing:.12em;margin-bottom:14px;}
.chart-title small{color:var(--muted);font-size:.6rem;margin-left:6px;}
.chart-wrap{position:relative;height:200px;}
.chart-wrap.short{height:160px;}

/* TOOLBAR */
.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.filter-select,.filter-input{background:var(--panel);border:1px solid var(--border);
  color:var(--text);padding:7px 12px;border-radius:4px;font-size:.82rem;font-family:var(--font);outline:none;transition:border-color .2s;}
.filter-select:focus,.filter-input:focus{border-color:var(--cyan);}
.filter-input::placeholder{color:var(--muted);}
.btn{padding:7px 16px;border-radius:4px;border:1px solid;cursor:pointer;font-size:.82rem;font-weight:700;
  font-family:var(--font);letter-spacing:.05em;transition:all .2s;text-transform:uppercase;}
.btn-cyan{background:rgba(0,212,255,.1);border-color:var(--cyan);color:var(--cyan);}
.btn-cyan:hover{background:rgba(0,212,255,.2);box-shadow:0 0 12px rgba(0,212,255,.3);}
.btn-orange{background:rgba(255,107,43,.1);border-color:var(--orange);color:var(--orange);}
.btn-orange:hover{background:rgba(255,107,43,.2);}
.btn-green{background:rgba(0,255,136,.1);border-color:var(--green);color:var(--green);}
.btn-green:hover{background:rgba(0,255,136,.2);}
.btn-red{background:rgba(255,45,85,.1);border-color:var(--red);color:var(--red);}
.btn-red:hover{background:rgba(255,45,85,.2);}
.btn-muted{background:rgba(255,255,255,.05);border-color:var(--border);color:var(--text2);}
.btn-muted:hover{border-color:var(--text2);}

/* TABLE */
.tbl-wrap{background:var(--panel);border:1px solid var(--border);border-radius:6px;overflow-x:auto;overflow-y:hidden;width:100%;}
table{width:100%;border-collapse:collapse;font-size:.82rem;}
thead{background:rgba(0,212,255,.04);}
th{padding:10px 14px;text-align:left;font-size:.65rem;font-family:var(--mono);color:var(--muted);
  text-transform:uppercase;letter-spacing:.1em;border-bottom:1px solid var(--border);font-weight:400;}
td{padding:10px 14px;border-bottom:1px solid rgba(13,45,69,.5);font-family:var(--mono);
  font-size:.8rem;color:var(--text);vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:rgba(0,212,255,.03);}
code{color:var(--cyan2);font-family:var(--mono);}

/* BADGES */
.badge{display:inline-block;padding:3px 10px;border-radius:3px;font-size:.68rem;font-family:var(--mono);font-weight:700;letter-spacing:.08em;border:1px solid;}
.badge-hs{color:var(--red);    border-color:rgba(255,45,85,.4); background:rgba(255,45,85,.1);}
.badge-s {color:var(--orange); border-color:rgba(255,107,43,.4);background:rgba(255,107,43,.1);}
.badge-n {color:var(--green);  border-color:rgba(0,255,136,.4); background:rgba(0,255,136,.1);}
.badge-u {color:var(--muted);  border-color:var(--border);      background:transparent;}
.badge-ok{color:var(--cyan);   border-color:rgba(0,212,255,.4); background:rgba(0,212,255,.1);}

/* MODAL */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(3,11,18,.85);z-index:900;
  align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.modal-bg.open{display:flex;}
.modal{background:var(--panel);border:1px solid var(--border2);border-radius:8px;padding:28px;
  max-width:720px;width:92%;max-height:82vh;overflow-y:auto;box-shadow:0 0 60px rgba(0,212,255,.1);}
.modal.wide{max-width:900px;}
.modal.xl{max-width:1100px;}
.modal-title{font-size:.9rem;font-family:var(--mono);color:var(--cyan);text-transform:uppercase;
  letter-spacing:.15em;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid var(--border);
  display:flex;justify-content:space-between;align-items:center;}
.close-x{cursor:pointer;color:var(--muted);font-size:1.1rem;}
.close-x:hover{color:var(--red);}
pre{background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:14px;font-size:.75rem;
  font-family:var(--mono);color:var(--cyan2);overflow-x:auto;white-space:pre-wrap;line-height:1.6;}
.detail-row{display:flex;gap:8px;margin-bottom:8px;font-size:.8rem;}
.detail-key{color:var(--muted);font-family:var(--mono);width:120px;flex-shrink:0;}
.detail-val{color:var(--text);font-family:var(--mono);}

/* LIVE LOG */
.live-log{background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:14px;
  height:120px;overflow-y:auto;font-family:var(--mono);font-size:.72rem;line-height:1.8;}
.log-entry{display:flex;gap:10px;}
.log-time{color:var(--muted);}
.log-msg{color:var(--cyan2);}
.log-msg.warn{color:var(--orange);}
.log-msg.danger{color:var(--red);}

/* TOAST */
#toast{position:fixed;bottom:24px;right:24px;background:var(--panel);border:1px solid var(--cyan);
  color:var(--cyan);padding:10px 20px;border-radius:4px;font-family:var(--mono);font-size:.8rem;
  display:none;z-index:9999;box-shadow:0 0 20px rgba(0,212,255,.3);animation:slideIn .3s ease;}
#toast.err{border-color:var(--red);color:var(--red);box-shadow:0 0 20px rgba(255,45,85,.3);}
@keyframes slideIn{from{transform:translateY(20px);opacity:0;}to{transform:translateY(0);opacity:1;}}

.grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;width:100%;}

/* ── RULES DASHBOARD ── */
.rules-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px;}
.rule-card{background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:14px;}
.rule-card-header{font-size:.68rem;font-family:var(--mono);color:var(--cyan2);text-transform:uppercase;
  letter-spacing:.1em;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;}
.rule-card pre{height:140px;overflow-y:auto;font-size:.7rem;margin-top:0;}

/* ── CHART DETAIL MODAL ── */
.chart-detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px;}
.detail-stat-box{background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:14px;text-align:center;}
.detail-stat-box .big{font-size:2rem;font-family:var(--mono);font-weight:700;margin:6px 0;}
.detail-stat-box .lbl{font-size:.65rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.1em;}
.detail-ip-list{margin-top:12px;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:14px;}
.detail-ip-list .ip-row{display:flex;justify-content:space-between;padding:5px 0;
  border-bottom:1px solid rgba(13,45,69,.5);font-family:var(--mono);font-size:.78rem;}
.detail-ip-list .ip-row:last-child{border-bottom:none;}

/* ── MISP EXPORT MODAL ── */
.misp-ioc-list{max-height:300px;overflow-y:auto;margin:10px 0;}
.misp-ioc-row{display:flex;align-items:center;gap:10px;padding:7px 10px;border-bottom:1px solid rgba(13,45,69,.5);font-family:var(--mono);font-size:.78rem;}
.misp-ioc-row:last-child{border-bottom:none;}
.misp-ioc-row input[type=checkbox]{accent-color:var(--cyan);width:14px;height:14px;cursor:pointer;}
.misp-actions{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap;}
.misp-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px;}
.misp-sum-box{background:var(--bg);border:1px solid var(--border);border-radius:4px;padding:10px;text-align:center;}
.misp-sum-box .n{font-size:1.4rem;font-family:var(--mono);font-weight:700;color:var(--cyan);}
.misp-sum-box .t{font-size:.6rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
  <div class="logo">
    <div class="logo-icon">&#11041;</div>
    NEURO-TRAP
  </div>
  <div style="font-size:.7rem;font-family:var(--mono);color:var(--muted);letter-spacing:.1em;">
    THREAT INTELLIGENCE PLATFORM // v2.1
  </div>
  <div class="status-bar">
    <div class="status-item"><div class="dot"></div> HONEYPOT ACTIVE</div>
    <div class="status-item"><div class="dot"></div> ML ENGINE ONLINE</div>
    <div class="status-item"><div class="dot red" id="threatDot"></div> <span id="threatStatus">MONITORING</span></div>
    <div class="time-display" id="clock">--:--:--</div>
  </div>
</div>

<div class="layout">
  <!-- SIDEBAR -->
  <div class="sidebar">
    <div class="sidebar-section">Navigation</div>
    <div class="nav-item active" id="nav-overview" onclick="switchPanel('overview')">
      <span class="nav-icon">&#9672;</span> Overview
    </div>
    <div class="nav-item" id="nav-sessions" onclick="switchPanel('sessions')">
      <span class="nav-icon">&#11041;</span> Sessions
      <span class="nav-badge" id="nb-sessions">0</span>
    </div>
    <div class="nav-item" id="nav-iocs" onclick="switchPanel('iocs')">
      <span class="nav-icon">&#9678;</span> IoC Registry
      <span class="nav-badge orange" id="nb-iocs">0</span>
    </div>
    <div class="nav-item" id="nav-rules" onclick="switchPanel('rules')">
      <span class="nav-icon">&#9632;</span> Rules Dashboard
    </div>
    <div class="nav-item" id="nav-decoys" onclick="switchPanel('decoys')">
      <span class="nav-icon">&#9671;</span> Decoy Events
    </div>

    <div class="sidebar-section">Actions</div>
    <div class="nav-item" onclick="runML()">
      <span class="nav-icon">&#9654;</span> Run ML Analysis
    </div>
    <div class="nav-item" onclick="runExtraction()">
      <span class="nav-icon">&#8853;</span> Extract IoCs
    </div>
    <div class="nav-item" onclick="openMISPModal()">
      <span class="nav-icon">&#8599;</span> Export MISP
    </div>
    <div class="nav-item" onclick="quickPDFExport()" style="padding-left:32px;font-size:.8rem;">
      <span class="nav-icon" style="font-size:.85rem;">&#128196;</span> Quick PDF
    </div>
    <div class="nav-item" onclick="downloadCSV()">
      <span class="nav-icon">&#8595;</span> Download CSV
    </div>

    <div class="sidebar-bottom">
      <div class="threat-level-label">Threat Level</div>
      <div class="threat-bar"><div class="threat-fill" id="threatFill"></div></div>
      <div class="threat-pct" id="threatPct">LOW — 0%</div>
    </div>
  </div>

  <!-- MAIN -->
  <div class="main">

    <!-- STAT CARDS (Enhanced with ML real-time detail) -->
    <div class="stats-grid">
      <div class="stat-card cyan" onclick="switchPanel('sessions')">
        <div class="stat-label">Total Sessions</div>
        <div class="stat-value" id="cTotal">0</div>
        <div class="stat-sub">captured connections</div>
        <div class="stat-ml-detail">Avg Score: <span id="avgScore">—</span><br>Last: <span id="lastSession">—</span></div>
      </div>
      <div class="stat-card red" onclick="showChartDetail('highly')">
        <div class="stat-label">Highly Suspicious</div>
        <div class="stat-value" id="cHS">0</div>
        <div class="stat-sub">critical threats</div>
        <div class="stat-ml-detail">Avg Score: <span id="hsAvgScore">—</span><br>Top IP: <span id="hsTopIP">—</span></div>
      </div>
      <div class="stat-card orange" onclick="showChartDetail('suspicious')">
        <div class="stat-label">Suspicious</div>
        <div class="stat-value" id="cS">0</div>
        <div class="stat-sub">anomalies detected</div>
        <div class="stat-ml-detail">Avg Score: <span id="sAvgScore">—</span><br>Top IP: <span id="sTopIP">—</span></div>
      </div>
      <div class="stat-card green" onclick="showChartDetail('normal')">
        <div class="stat-label">Normal</div>
        <div class="stat-value" id="cN">0</div>
        <div class="stat-sub">benign traffic</div>
        <div class="stat-ml-detail">Avg Score: <span id="nAvgScore">—</span><br>Last: <span id="nLastTime">—</span></div>
      </div>
      <div class="stat-card yellow" onclick="switchPanel('iocs')">
        <div class="stat-label">Total IoCs</div>
        <div class="stat-value" id="cIoC">0</div>
        <div class="stat-sub">indicators found</div>
        <div class="stat-ml-detail">Approved: <span id="iocApproved">—</span><br>Pending: <span id="iocPending">—</span></div>
      </div>
    </div>

    <!-- OVERVIEW PANEL -->
    <div class="panel active" id="panel-overview">
      <div class="section-header">Threat Analysis Overview</div>
      <div class="chart-row">
        <div class="chart-box clickable" onclick="showChartDetail('doughnut')" title="Click for breakdown">
          <div class="chart-title">Session Risk Distribution <small>▶ click for details</small></div>
          <div class="chart-wrap"><canvas id="chartDoughnut"></canvas></div>
        </div>
        <div class="chart-box clickable" onclick="showChartDetail('bar')" title="Click for ML score details">
          <div class="chart-title">ML Score Distribution <small>▶ click for details</small></div>
          <div class="chart-wrap"><canvas id="chartBar"></canvas></div>
        </div>
        <div class="chart-box clickable" onclick="showChartDetail('ioc')" title="Click for IoC breakdown">
          <div class="chart-title">IoC Type Breakdown <small>▶ click for details</small></div>
          <div class="chart-wrap" style="height:200px;position:relative;"><canvas id="chartIoC"></canvas></div>
        </div>
      </div>
      <div class="grid2">
        <div class="chart-box">
          <div class="chart-title">Session Timeline (sessions per hour)</div>
          <div class="chart-wrap short"><canvas id="chartTimeline"></canvas></div>
        </div>
        <div class="chart-box">
          <div class="chart-title" style="margin-bottom:10px;">Live Activity Log</div>
          <div class="live-log" id="liveLog">
            <div class="log-entry"><span class="log-time">--:--:--</span><span class="log-msg">System initialised. Awaiting connections...</span></div>
          </div>
        </div>
      </div>
    </div>

    <!-- SESSIONS PANEL -->
    <div class="panel" id="panel-sessions">
      <div class="section-header">Session Registry</div>
      <div class="toolbar">
        <select class="filter-select" id="filterLabel" onchange="loadSessions()">
          <option value="">All Labels</option>
          <option value="HIGHLY_SUSPICIOUS">Highly Suspicious</option>
          <option value="SUSPICIOUS">Suspicious</option>
          <option value="NORMAL">Normal</option>
          <option value="UNSCORED">Unscored</option>
        </select>
        <input class="filter-input" id="filterIP" placeholder="Filter by IP..." oninput="loadSessions()" style="width:160px">
        <button class="btn btn-cyan"   onclick="runML()">&#9654; RUN ML</button>
        <button class="btn btn-orange" onclick="runExtraction()">&#8853; EXTRACT IoCs</button>
        <button class="btn btn-muted"  onclick="downloadCSV()">&#8595; CSV</button>
      </div>
      <div class="tbl-wrap">
        <table>
          <thead><tr>
            <th>#</th><th>Timestamp</th><th>Source IP</th><th>Port</th>
            <th>Duration</th><th>Bytes</th><th>ML Score</th><th>Risk Label</th><th>Action</th>
          </tr></thead>
          <tbody id="sessionBody"></tbody>
        </table>
      </div>
    </div>

    <!-- IoCs PANEL -->
    <div class="panel" id="panel-iocs">
      <div class="section-header">Indicator of Compromise Registry</div>
      <div class="toolbar">
        <select class="filter-select" id="filterIocType" onchange="loadIoCs()">
          <option value="">All Types</option>
          <option value="ip">IP Address</option>
          <option value="domain">Domain</option>
          <option value="url">URL</option>
          <option value="md5">MD5 Hash</option>
          <option value="sha256">SHA-256</option>
          <option value="cve">CVE</option>
          <option value="malicious_cmd">Command</option>
        </select>
        <select class="filter-select" id="filterApproved" onchange="loadIoCs()">
          <option value="">All Status</option>
          <option value="1">Approved</option>
          <option value="0">Pending</option>
        </select>
        <button class="btn btn-green" onclick="openMISPModal()">&#8599; EXPORT MISP PDF</button>
      </div>
      <div class="tbl-wrap">
        <table>
          <thead><tr>
            <th>#</th><th>Session</th><th>Type</th><th>Value</th>
            <th>Extracted</th><th>Status</th><th>Actions</th>
          </tr></thead>
          <tbody id="iocBody"></tbody>
        </table>
      </div>
    </div>

    <!-- RULES DASHBOARD PANEL -->
    <div class="panel" id="panel-rules">
      <div class="section-header">Detection Rules Dashboard</div>
      <div class="toolbar" style="margin-bottom:4px;">
        <select class="filter-select" id="filterRuleType" onchange="loadRules()">
          <option value="">All Types</option>
          <option value="ip">IP</option>
          <option value="domain">Domain</option>
          <option value="url">URL</option>
          <option value="malicious_cmd">Command</option>
          <option value="md5">MD5</option>
          <option value="sha256">SHA256</option>
          <option value="cve">CVE</option>
        </select>
        <select class="filter-select" id="filterRuleApproved" onchange="loadRules()">
          <option value="">All Status</option>
          <option value="1">Approved Only</option>
          <option value="0">Pending Only</option>
        </select>
        <button class="btn btn-cyan" onclick="downloadAllRules()">&#8595; DOWNLOAD ALL RULES</button>
      </div>
      <!-- Stats row -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;" id="rulesSummaryRow"></div>
      <!-- Rules grid cards -->
      <div id="rulesGrid" class="rules-grid"></div>
    </div>

    <!-- DECOYS PANEL -->
    <div class="panel" id="panel-decoys">
      <div class="section-header">Decoy Service Events</div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>#</th><th>Session</th><th>Port</th><th>Service</th><th>Spawned At</th></tr></thead>
          <tbody id="decoyBody"></tbody>
        </table>
      </div>
    </div>

  </div><!-- /main -->
</div><!-- /layout -->

<!-- Session Modal -->
<div class="modal-bg" id="modalBg">
  <div class="modal">
    <div class="modal-title">
      <span id="modalTitle">Session Detail</span>
      <span class="close-x" onclick="closeModal()">&#10005;</span>
    </div>
    <div id="modalContent"></div>
  </div>
</div>

<!-- Rules Modal (single IoC) -->
<div class="modal-bg" id="ruleModalBg">
  <div class="modal wide">
    <div class="modal-title">
      <span id="ruleModalTitle">Detection Rules</span>
      <span class="close-x" onclick="closeRuleModal()">&#10005;</span>
    </div>
    <div id="ruleModalContent"></div>
  </div>
</div>

<!-- Chart Detail Modal -->
<div class="modal-bg" id="chartDetailBg">
  <div class="modal wide">
    <div class="modal-title">
      <span id="chartDetailTitle">Detail View</span>
      <span class="close-x" onclick="document.getElementById('chartDetailBg').classList.remove('open')">&#10005;</span>
    </div>
    <div id="chartDetailContent"></div>
  </div>
</div>

<!-- MISP Export Modal -->
<div class="modal-bg" id="mispModalBg">
  <div class="modal wide">
    <div class="modal-title">
      <span>MISP Export Dashboard</span>
      <span class="close-x" onclick="document.getElementById('mispModalBg').classList.remove('open')">&#10005;</span>
    </div>
    <div id="mispModalContent"></div>
  </div>
</div>

<div id="toast"></div>

<script>
// ── Clock ──────────────────────────────────────────────────────────────────────
function updateClock(){ document.getElementById('clock').textContent=new Date().toTimeString().slice(0,8); }
setInterval(updateClock,1000); updateClock();

// ── Toast ──────────────────────────────────────────────────────────────────────
function toast(msg,ok=true){
  const t=document.getElementById('toast');
  t.textContent=msg; t.className=ok?'':'err';
  t.style.display='block'; setTimeout(()=>t.style.display='none',3500);
}

// ── Log ────────────────────────────────────────────────────────────────────────
function addLog(msg,type=''){
  const log=document.getElementById('liveLog');
  const ts=new Date().toTimeString().slice(0,8);
  const div=document.createElement('div');
  div.className='log-entry';
  div.innerHTML=`<span class="log-time">${ts}</span><span class="log-msg ${type}">${msg}</span>`;
  log.appendChild(div); log.scrollTop=log.scrollHeight;
}

// ── Badge ──────────────────────────────────────────────────────────────────────
function labelBadge(lbl){
  const m={'HIGHLY_SUSPICIOUS':'badge-hs','SUSPICIOUS':'badge-s','NORMAL':'badge-n','UNSCORED':'badge-u'};
  return `<span class="badge ${m[lbl]||'badge-u'}">${lbl}</span>`;
}

// ── Nav ────────────────────────────────────────────────────────────────────────
function switchPanel(name){
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
  document.getElementById('nav-'+name)?.classList.add('active');
  document.getElementById('panel-'+name).classList.add('active');
  if(name==='sessions') loadSessions();
  if(name==='iocs')     loadIoCs();
  if(name==='decoys')   loadDecoys();
  if(name==='overview') loadCharts();
  if(name==='rules')    loadRules();
}

// ── Stats (enhanced with ML real-time details) ─────────────────────────────────
let statsCache={total:0,highly:0,suspicious:0,normal:0,iocs:0};
let allSessionsCache=[];

async function loadStats(){
  const r=await fetch('/api/stats'); const d=await r.json();
  statsCache=d;
  document.getElementById('cTotal').textContent=d.total??0;
  document.getElementById('cHS').textContent=d.highly??0;
  document.getElementById('cS').textContent=d.suspicious??0;
  document.getElementById('cN').textContent=d.normal??0;
  document.getElementById('cIoC').textContent=d.iocs??0;
  document.getElementById('nb-sessions').textContent=d.total??0;
  document.getElementById('nb-iocs').textContent=d.iocs??0;

  // ── Enhanced ML details in stat cards
  const sessions=await fetch('/api/sessions').then(r=>r.json());
  allSessionsCache=sessions;
  const scored=sessions.filter(s=>s.ml_score!==null);
  const avg=v=>v.length?v.reduce((a,b)=>a+b,0)/v.length:null;
  const fmt=v=>v!==null?v.toFixed(4):'—';
  const topIP=arr=>{
    const counts={};
    arr.forEach(s=>{counts[s.src_ip]=(counts[s.src_ip]||0)+1;});
    const sorted=Object.entries(counts).sort((a,b)=>b[1]-a[1]);
    return sorted.length?sorted[0][0]:'—';
  };

  const allScores=scored.map(s=>parseFloat(s.ml_score));
  document.getElementById('avgScore').textContent=fmt(avg(allScores));

  const lastS=sessions[0];
  document.getElementById('lastSession').textContent=lastS?lastS.timestamp?.slice(11,19)||'—':'—';

  const hsSessions=scored.filter(s=>s.risk_label==='HIGHLY_SUSPICIOUS');
  document.getElementById('hsAvgScore').textContent=fmt(avg(hsSessions.map(s=>parseFloat(s.ml_score))));
  document.getElementById('hsTopIP').textContent=topIP(hsSessions);

  const sSessions=scored.filter(s=>s.risk_label==='SUSPICIOUS');
  document.getElementById('sAvgScore').textContent=fmt(avg(sSessions.map(s=>parseFloat(s.ml_score))));
  document.getElementById('sTopIP').textContent=topIP(sSessions);

  const nSessions=scored.filter(s=>s.risk_label==='NORMAL');
  document.getElementById('nAvgScore').textContent=fmt(avg(nSessions.map(s=>parseFloat(s.ml_score))));
  const lastN=nSessions[0];
  document.getElementById('nLastTime').textContent=lastN?lastN.timestamp?.slice(11,19)||'—':'—';

  // IoC approved/pending
  try{
    const iocAll=await fetch('/api/iocs').then(r=>r.json());
    const approved=iocAll.filter(i=>i.approved).length;
    document.getElementById('iocApproved').textContent=approved;
    document.getElementById('iocPending').textContent=iocAll.length-approved;
  }catch(e){}

  // Threat level
  const total=d.total||1;
  const pct=Math.min(Math.round(((d.highly*3+d.suspicious*1.5)/total)*20),100);
  document.getElementById('threatFill').style.width=pct+'%';
  const lvl=pct>60?'CRITICAL':pct>30?'HIGH':pct>10?'MEDIUM':'LOW';
  document.getElementById('threatPct').textContent=`${lvl} — ${pct}%`;
  if(d.highly>0){
    document.getElementById('threatDot').className='dot red';
    document.getElementById('threatStatus').textContent='THREAT DETECTED';
  } else {
    document.getElementById('threatDot').className='dot';
    document.getElementById('threatStatus').textContent='MONITORING';
  }
}

// ── Chart Detail Modal (click on chart → breakdown) ───────────────────────────
async function showChartDetail(type){
  const d=statsCache;
  const sessions=allSessionsCache.length?allSessionsCache:await fetch('/api/sessions').then(r=>r.json());
  const bg=document.getElementById('chartDetailBg');
  const title=document.getElementById('chartDetailTitle');
  const content=document.getElementById('chartDetailContent');

  if(type==='doughnut' || type==='highly' || type==='suspicious' || type==='normal'){
    title.textContent='Session Risk Distribution — Breakdown';
    const unscored=Math.max(0,d.total-d.normal-d.suspicious-d.highly);
    const hsSessions=sessions.filter(s=>s.risk_label==='HIGHLY_SUSPICIOUS');
    const sSessions=sessions.filter(s=>s.risk_label==='SUSPICIOUS');
    const nSessions=sessions.filter(s=>s.risk_label==='NORMAL');

    const ipTable=(arr,color)=>{
      const counts={};
      arr.forEach(s=>{counts[s.src_ip]=(counts[s.src_ip]||0)+1;});
      const rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,5);
      if(!rows.length) return '<div style="color:var(--muted);font-family:var(--mono);font-size:.75rem;text-align:center;padding:10px;">No sessions</div>';
      return rows.map(([ip,cnt])=>`<div class="ip-row"><span style="color:${color}">${ip}</span><span style="color:var(--muted)">${cnt} session${cnt!==1?'s':''}</span></div>`).join('');
    };

    const avgScore=arr=>{
      const sc=arr.filter(s=>s.ml_score!==null).map(s=>parseFloat(s.ml_score));
      return sc.length?(sc.reduce((a,b)=>a+b,0)/sc.length).toFixed(4):'—';
    };

    content.innerHTML=`
      <div class="chart-detail-grid">
        <div class="detail-stat-box"><div class="lbl">Highly Suspicious</div><div class="big" style="color:var(--red)">${d.highly}</div><div style="font-size:.7rem;color:var(--muted);font-family:var(--mono);">Avg Score: ${avgScore(hsSessions)}</div></div>
        <div class="detail-stat-box"><div class="lbl">Suspicious</div><div class="big" style="color:var(--orange)">${d.suspicious}</div><div style="font-size:.7rem;color:var(--muted);font-family:var(--mono);">Avg Score: ${avgScore(sSessions)}</div></div>
        <div class="detail-stat-box"><div class="lbl">Normal</div><div class="big" style="color:var(--green)">${d.normal}</div><div style="font-size:.7rem;color:var(--muted);font-family:var(--mono);">Avg Score: ${avgScore(nSessions)}</div></div>
        <div class="detail-stat-box"><div class="lbl">Unscored</div><div class="big" style="color:var(--muted)">${unscored}</div><div style="font-size:.7rem;color:var(--muted);font-family:var(--mono);">Awaiting ML</div></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:12px;">
        <div class="detail-ip-list"><div style="font-size:.65rem;font-family:var(--mono);color:var(--red);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Top HIGHLY_SUSPICIOUS IPs</div>${ipTable(hsSessions,'var(--red)')}</div>
        <div class="detail-ip-list"><div style="font-size:.65rem;font-family:var(--mono);color:var(--orange);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Top SUSPICIOUS IPs</div>${ipTable(sSessions,'var(--orange)')}</div>
        <div class="detail-ip-list"><div style="font-size:.65rem;font-family:var(--mono);color:var(--green);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Top NORMAL IPs</div>${ipTable(nSessions,'var(--green)')}</div>
      </div>
      <div style="margin-top:14px;text-align:right;">
        <button class="btn btn-cyan" onclick="switchPanel('sessions');document.getElementById('chartDetailBg').classList.remove('open')">View All Sessions &#8594;</button>
      </div>`;
  }

  else if(type==='bar'){
    title.textContent='ML Score Distribution — Breakdown';
    const scored=sessions.filter(s=>s.ml_score!==null);
    const scores=scored.map(s=>parseFloat(s.ml_score));
    const min=scores.length?Math.min(...scores).toFixed(4):'—';
    const max=scores.length?Math.max(...scores).toFixed(4):'—';
    const avg=scores.length?(scores.reduce((a,b)=>a+b,0)/scores.length).toFixed(4):'—';
    const highly=scored.filter(s=>s.risk_label==='HIGHLY_SUSPICIOUS');
    const susp=scored.filter(s=>s.risk_label==='SUSPICIOUS');
    const norm=scored.filter(s=>s.risk_label==='NORMAL');

    const recentHS=highly.slice(0,5).map(s=>`<div class="ip-row"><span style="color:var(--red)">${s.src_ip}</span><span style="color:var(--muted)">${parseFloat(s.ml_score).toFixed(4)}</span></div>`).join('');

    content.innerHTML=`
      <div class="chart-detail-grid">
        <div class="detail-stat-box"><div class="lbl">Min Score</div><div class="big" style="color:var(--red);font-size:1.4rem">${min}</div></div>
        <div class="detail-stat-box"><div class="lbl">Max Score</div><div class="big" style="color:var(--green);font-size:1.4rem">${max}</div></div>
        <div class="detail-stat-box"><div class="lbl">Average Score</div><div class="big" style="color:var(--cyan);font-size:1.4rem">${avg}</div></div>
        <div class="detail-stat-box"><div class="lbl">Total Scored</div><div class="big" style="color:var(--text);font-size:1.4rem">${scored.length}</div></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px;">
        <div class="detail-ip-list">
          <div style="font-size:.65rem;font-family:var(--mono);color:var(--cyan);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Score Bands</div>
          <div class="ip-row"><span style="color:var(--red)">Highly Suspicious (&lt;-0.10)</span><span>${highly.length}</span></div>
          <div class="ip-row"><span style="color:var(--orange)">Suspicious (-0.10 to 0)</span><span>${susp.length}</span></div>
          <div class="ip-row"><span style="color:var(--green)">Normal (&gt;0)</span><span>${norm.length}</span></div>
        </div>
        <div class="detail-ip-list">
          <div style="font-size:.65rem;font-family:var(--mono);color:var(--red);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Top Critical (by score)</div>
          ${recentHS||'<div style="color:var(--muted);font-size:.75rem;text-align:center;padding:10px;">None</div>'}
        </div>
      </div>`;
  }

  else if(type==='ioc'){
    title.textContent='IoC Type Breakdown — Detail';
    try{
      const iocs=await fetch('/api/iocs').then(r=>r.json());
      const counts={ip:0,domain:0,url:0,md5:0,sha256:0,malicious_cmd:0,cve:0};
      iocs.forEach(i=>{if(counts.hasOwnProperty(i.ioc_type))counts[i.ioc_type]++;});
      const approved=iocs.filter(i=>i.approved).length;
      const rows=Object.entries(counts).map(([k,v])=>`<div class="ip-row"><span style="color:var(--cyan2);text-transform:uppercase">${k}</span><span style="color:var(--text)">${v}</span></div>`).join('');
      content.innerHTML=`
        <div class="chart-detail-grid">
          <div class="detail-stat-box"><div class="lbl">Total IoCs</div><div class="big" style="color:var(--yellow)">${iocs.length}</div></div>
          <div class="detail-stat-box"><div class="lbl">Approved</div><div class="big" style="color:var(--green)">${approved}</div></div>
          <div class="detail-stat-box"><div class="lbl">Pending</div><div class="big" style="color:var(--orange)">${iocs.length-approved}</div></div>
          <div class="detail-stat-box"><div class="lbl">Types Found</div><div class="big" style="color:var(--cyan)">${Object.values(counts).filter(v=>v>0).length}</div></div>
        </div>
        <div class="detail-ip-list" style="margin-top:12px;">
          <div style="font-size:.65rem;font-family:var(--mono);color:var(--cyan);text-transform:uppercase;margin-bottom:8px;letter-spacing:.1em;">Breakdown by Type</div>
          ${rows}
        </div>
        <div style="margin-top:14px;text-align:right;">
          <button class="btn btn-green" onclick="openMISPModal();document.getElementById('chartDetailBg').classList.remove('open')">Export MISP PDF &#8599;</button>
        </div>`;
    }catch(e){content.innerHTML='<div style="color:var(--muted);">No IoC data available.</div>';}
  }

  bg.classList.add('open');
}

// ── Charts ─────────────────────────────────────────────────────────────────────
let charts={};
function destroyChart(key){ if(charts[key]){ charts[key].destroy(); charts[key]=null; } }
const TICK_STYLE={color:'#3a6880',font:{family:'Share Tech Mono',size:9}};
const GRID_STYLE={color:'rgba(13,45,69,.6)'};

async function loadCharts(){
  await loadStats();
  const d=statsCache;

  // 1. Doughnut
  destroyChart('doughnut');
  const unscored=Math.max(0,d.total-d.normal-d.suspicious-d.highly);
  charts.doughnut=new Chart(document.getElementById('chartDoughnut'),{
    type:'doughnut',
    data:{
      labels:['Normal','Suspicious','Highly Suspicious','Unscored'],
      datasets:[{data:[d.normal,d.suspicious,d.highly,unscored],
        backgroundColor:['rgba(0,255,136,.7)','rgba(255,107,43,.7)','rgba(255,45,85,.7)','rgba(58,104,128,.4)'],
        borderColor:['#00ff88','#ff6b2b','#ff2d55','#3a6880'],borderWidth:1,hoverOffset:4}]
    },
    options:{responsive:true,maintainAspectRatio:false,cutout:'60%',
      plugins:{legend:{position:'bottom',labels:{color:'#6ba3be',font:{family:'Share Tech Mono',size:9},padding:8,boxWidth:10}},
        tooltip:{callbacks:{afterLabel:()=>'Click chart for details'}}}}
  });

  // 2. Bar: ML Score Distribution
  const sessions=await fetch('/api/sessions').then(r=>r.json());
  allSessionsCache=sessions;
  const scored=sessions.filter(s=>s.ml_score!==null);
  const binEdges=[-Infinity,-0.3,-0.1,0.0,0.1,0.3,Infinity];
  const binLabels=['< -0.30','-0.30 to -0.10','-0.10 to 0','0 to 0.10','0.10 to 0.30','> 0.30'];
  const binColors=['rgba(255,45,85,.8)','rgba(255,107,43,.8)','rgba(255,214,10,.7)','rgba(0,212,255,.6)','rgba(0,255,136,.7)','rgba(0,255,136,.85)'];
  const binBorders=['#ff2d55','#ff6b2b','#ffd60a','#00d4ff','#00ff88','#00ff88'];
  const counts=new Array(6).fill(0);
  scored.forEach(s=>{const sc=parseFloat(s.ml_score);for(let i=0;i<binEdges.length-1;i++){if(sc>=binEdges[i]&&sc<binEdges[i+1]){counts[i]++;break;}}});
  destroyChart('bar');
  charts.bar=new Chart(document.getElementById('chartBar'),{
    type:'bar',
    data:{labels:binLabels,datasets:[{label:'Sessions',data:counts,backgroundColor:binColors,borderColor:binBorders,borderWidth:1,borderRadius:3}]},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.parsed.y} session${ctx.parsed.y!==1?'s':''}`,title:ctx=>`Score: ${ctx[0].label}`}}},
      scales:{x:{ticks:{color:'#6ba3be',font:{family:'Share Tech Mono',size:9},maxRotation:30,minRotation:0},grid:GRID_STYLE},
        y:{ticks:{color:'#6ba3be',font:{family:'Share Tech Mono',size:10},stepSize:1,precision:0},grid:GRID_STYLE,beginAtZero:true}}}
  });

  // 3. Polar: IoC Breakdown
  let iocCounts={ip:0,domain:0,url:0,md5:0,sha256:0,malicious_cmd:0,cve:0};
  try{const iocs=await fetch('/api/iocs').then(r=>r.json());iocs.forEach(i=>{if(iocCounts.hasOwnProperty(i.ioc_type))iocCounts[i.ioc_type]++;else iocCounts.cve++;});}catch(e){}
  const iocLabels=['IP','Domain','URL','MD5','SHA256','Command','CVE'];
  const iocVals=Object.values(iocCounts);
  const hasIocData=iocVals.some(v=>v>0);
  destroyChart('ioc');
  charts.ioc=new Chart(document.getElementById('chartIoC'),{
    type:'polarArea',
    data:{labels:iocLabels,datasets:[{data:hasIocData?iocVals:[1,1,1,1,1,1,1],
      backgroundColor:['rgba(0,212,255,.65)','rgba(0,255,204,.65)','rgba(255,107,43,.65)','rgba(255,214,10,.65)','rgba(255,45,85,.65)','rgba(107,163,190,.65)','rgba(0,255,136,.65)'],
      borderColor:['#00d4ff','#00ffcc','#ff6b2b','#ffd60a','#ff2d55','#6ba3be','#00ff88'],borderWidth:1}]},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{position:'right',labels:{color:'#6ba3be',font:{family:'Share Tech Mono',size:9},padding:6,boxWidth:10}},
        tooltip:{callbacks:{label:ctx=>hasIocData?`${ctx.label}: ${ctx.parsed.r}`:'No data yet'}}},
      scales:{r:{ticks:{display:false},grid:{color:'rgba(13,45,69,.6)'},pointLabels:{display:false}}}}
  });

  // 4. Line: Timeline
  const hourCounts={};
  sessions.forEach(s=>{if(!s.timestamp)return;const h=s.timestamp.slice(11,13);hourCounts[h]=(hourCounts[h]||0)+1;});
  const allHours=Array.from({length:24},(_,i)=>String(i).padStart(2,'0'));
  const hourData=allHours.map(h=>hourCounts[h]||0);
  const hasActivity=hourData.some(v=>v>0);
  let displayHours=allHours,displayData=hourData;
  if(hasActivity){
    const firstIdx=hourData.findIndex(v=>v>0);
    const lastIdx=hourData.length-1-[...hourData].reverse().findIndex(v=>v>0);
    const start=Math.max(0,firstIdx-1),end=Math.min(23,lastIdx+1);
    displayHours=allHours.slice(start,end+1).map(h=>h+':00');
    displayData=hourData.slice(start,end+1);
  }else{displayHours=['00:00','06:00','12:00','18:00','23:00'];displayData=[0,0,0,0,0];}
  destroyChart('timeline');
  charts.timeline=new Chart(document.getElementById('chartTimeline'),{
    type:'line',
    data:{labels:displayHours,datasets:[{label:'Sessions',data:displayData,borderColor:'#00d4ff',
      backgroundColor:'rgba(0,212,255,.08)',pointBackgroundColor:'#00d4ff',pointBorderColor:'#00d4ff',
      pointRadius:4,pointHoverRadius:6,tension:.3,fill:true,borderWidth:2}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
      scales:{x:{ticks:{...TICK_STYLE,color:'#6ba3be'},grid:GRID_STYLE},
        y:{ticks:{color:'#6ba3be',font:{family:'Share Tech Mono',size:10},stepSize:1,precision:0},
          grid:GRID_STYLE,beginAtZero:true,min:0}}}
  });
}

// ── Sessions ───────────────────────────────────────────────────────────────────
async function loadSessions(){
  const label=document.getElementById('filterLabel').value;
  const ip=document.getElementById('filterIP').value.trim();
  const r=await fetch(`/api/sessions?label=${encodeURIComponent(label)}&ip=${encodeURIComponent(ip)}`);
  const rows=await r.json();
  const tbody=document.getElementById('sessionBody');
  tbody.innerHTML='';
  if(!rows.length){
    tbody.innerHTML='<tr><td colspan="9" style="text-align:center;color:var(--muted);padding:30px;font-family:var(--mono);">NO SESSIONS FOUND</td></tr>';
    return;
  }
  rows.forEach(s=>{
    const scoreColor=s.ml_score===null?'var(--muted)':s.ml_score<-0.1?'var(--red)':s.ml_score<0?'var(--orange)':'var(--green)';
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td style="color:var(--muted)">${s.id}</td>
      <td>${s.timestamp?.slice(0,19).replace('T',' ')||''}</td>
      <td><code>${s.src_ip}</code></td>
      <td style="color:var(--text2)">${s.src_port}</td>
      <td>${s.duration_sec}s</td>
      <td>${s.bytes_recv}B</td>
      <td style="color:${scoreColor}">${s.ml_score!==null?s.ml_score.toFixed(4):'—'}</td>
      <td>${labelBadge(s.risk_label)}</td>
      <td><button class="btn btn-muted" style="padding:4px 10px;font-size:.7rem" onclick="showDetail(${s.id})">VIEW</button></td>`;
    tbody.appendChild(tr);
  });
}

async function showDetail(id){
  const r=await fetch(`/api/sessions/${id}`); const s=await r.json();
  document.getElementById('modalTitle').textContent=`SESSION #${id} // ${s.src_ip}`;
  document.getElementById('modalContent').innerHTML=`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;">
      <div class="detail-row"><span class="detail-key">Risk Label</span><span class="detail-val">${labelBadge(s.risk_label)}</span></div>
      <div class="detail-row"><span class="detail-key">ML Score</span><span class="detail-val" style="color:var(--cyan)">${s.ml_score??'UNSCORED'}</span></div>
      <div class="detail-row"><span class="detail-key">Source IP</span><span class="detail-val"><code>${s.src_ip}</code></span></div>
      <div class="detail-row"><span class="detail-key">Duration</span><span class="detail-val">${s.duration_sec}s</span></div>
      <div class="detail-row"><span class="detail-key">Bytes Recv</span><span class="detail-val">${s.bytes_recv}</span></div>
      <div class="detail-row"><span class="detail-key">Timestamp</span><span class="detail-val">${s.timestamp?.slice(0,19)||''}</span></div>
    </div>
    <div style="font-size:.65rem;font-family:var(--mono);color:var(--muted);margin-bottom:6px;letter-spacing:.1em;">COMMANDS RECEIVED:</div>
    <pre>${s.commands||'(none)'}</pre>
    <div style="font-size:.65rem;font-family:var(--mono);color:var(--muted);margin:12px 0 6px;letter-spacing:.1em;">RAW PAYLOAD (first 800 chars):</div>
    <pre>${(s.payload_raw||'(empty)').slice(0,800)}</pre>`;
  document.getElementById('modalBg').classList.add('open');
  addLog(`Opened session #${id} from ${s.src_ip}`);
}
function closeModal(){ document.getElementById('modalBg').classList.remove('open'); }

// ── ML / Extraction ────────────────────────────────────────────────────────────
async function runML(){
  addLog('Running ML analysis engine...','warn');
  toast('Running ML Analysis...');
  const r=await fetch('/api/run_ml',{method:'POST'}); const d=await r.json();
  toast(`ML Analysis complete — ${d.scored} sessions scored`);
  addLog(`ML complete. ${d.scored} sessions scored.`);
  loadStats(); loadSessions(); loadCharts();
}
async function runExtraction(){
  addLog('Extracting IoCs from session payloads...','warn');
  toast('Extracting IoCs...');
  const r=await fetch('/api/run_extraction',{method:'POST'}); const d=await r.json();
  toast(`Extraction complete — ${d.iocs_found} IoCs found`);
  addLog(`IoC extraction done. ${d.iocs_found} indicators found.`);
  loadStats(); loadCharts();
}
function downloadCSV(){ window.location='/api/export_csv'; }

// Quick PDF export - selects all approved IoCs and downloads immediately
async function quickPDFExport(){
  addLog('Generating PDF export...','warn');
  toast('Generating PDF...');
  const r=await fetch('/api/export_misp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:[],format:'pdf'})});
  const d=await r.json();
  if(d.ok){
    toast('PDF ready — downloading...');
    addLog('PDF export complete. Downloading...');
    window.location='/api/download_misp_pdf';
  } else {
    toast(d.error||'PDF export failed. Approve some IoCs first.',false);
    addLog(d.error||'PDF failed','warn');
  }
}

// ── IoCs ───────────────────────────────────────────────────────────────────────
async function loadIoCs(){
  const type=document.getElementById('filterIocType').value;
  const approved=document.getElementById('filterApproved').value;
  const r=await fetch(`/api/iocs?type=${encodeURIComponent(type)}&approved=${encodeURIComponent(approved)}`);
  const rows=await r.json();
  const tbody=document.getElementById('iocBody');
  tbody.innerHTML='';
  if(!rows.length){
    tbody.innerHTML='<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:30px;font-family:var(--mono);">NO IoCs FOUND — RUN EXTRACTION FIRST</td></tr>';
    return;
  }
  rows.forEach(i=>{
    const status=i.approved?'<span class="badge badge-ok">APPROVED</span>':'<span class="badge badge-u">PENDING</span>';
    const approveBtn=!i.approved?`<button class="btn btn-green" style="padding:3px 10px;font-size:.68rem" onclick="approveIoC(${i.id})">APPROVE</button>`:'';
    const rulesBtn=`<button class="btn btn-muted" style="padding:3px 10px;font-size:.68rem" onclick="showRules(${i.id})">RULES</button>`;
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td style="color:var(--muted)">${i.id}</td>
      <td><code>#${i.session_id}</code></td>
      <td><span class="badge badge-ok" style="font-size:.65rem">${i.ioc_type.toUpperCase()}</span></td>
      <td style="max-width:240px;word-break:break-all;color:var(--cyan2)">${i.ioc_value}</td>
      <td style="color:var(--muted)">${i.extracted_at?.slice(0,16)||''}</td>
      <td>${status}</td>
      <td style="display:flex;gap:6px">${approveBtn}${rulesBtn}</td>`;
    tbody.appendChild(tr);
  });
}
async function approveIoC(id){
  const r=await fetch(`/api/iocs/${id}/approve`,{method:'POST'}); const d=await r.json();
  if(d.ok){toast('IoC approved');addLog(`IoC #${id} approved by analyst.`);loadIoCs();loadStats();}
  else toast('Error approving IoC',false);
}
async function showRules(id){
  const r=await fetch(`/api/iocs/${id}`); const d=await r.json();
  document.getElementById('ruleModalTitle').textContent=`DETECTION RULES // ${d.ioc_type.toUpperCase()}: ${d.ioc_value}`;
  document.getElementById('ruleModalContent').innerHTML=`
    <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap;">
      <span class="badge badge-ok">${d.ioc_type.toUpperCase()}</span>
      <span style="font-family:var(--mono);font-size:.78rem;color:var(--cyan2)">${d.ioc_value}</span>
      ${d.approved?'<span class="badge badge-n">APPROVED</span>':'<span class="badge badge-u">PENDING</span>'}
    </div>
    <div style="font-size:.65rem;font-family:var(--mono);color:var(--muted);margin-bottom:8px;letter-spacing:.1em;">▶ YARA RULE:</div>
    <pre>${d.yara_rule||'N/A'}</pre>
    <div style="font-size:.65rem;font-family:var(--mono);color:var(--muted);margin:14px 0 8px;letter-spacing:.1em;">▶ SURICATA RULE:</div>
    <pre>${d.suricata_rule||'N/A'}</pre>
    <div style="margin-top:14px;display:flex;gap:10px;">
      <button class="btn btn-cyan" onclick="downloadSingleRule(${id})">&#8595; Download Rules</button>
      ${!d.approved?`<button class="btn btn-green" onclick="approveIoC(${id});closeRuleModal()">&#10003; Approve IoC</button>`:''}
    </div>`;
  document.getElementById('ruleModalBg').classList.add('open');
}
function closeRuleModal(){ document.getElementById('ruleModalBg').classList.remove('open'); }

function downloadSingleRule(id){
  window.location=`/api/iocs/${id}/download_rules`;
}

// ── Rules Dashboard ────────────────────────────────────────────────────────────
async function loadRules(){
  const type=document.getElementById('filterRuleType').value;
  const approved=document.getElementById('filterRuleApproved').value;
  const r=await fetch(`/api/iocs?type=${encodeURIComponent(type)}&approved=${encodeURIComponent(approved)}`);
  const iocs=await r.json();

  // Summary row
  const types={};
  iocs.forEach(i=>{types[i.ioc_type]=(types[i.ioc_type]||0)+1;});
  const summaryEl=document.getElementById('rulesSummaryRow');
  summaryEl.innerHTML=Object.entries(types).map(([t,n])=>`
    <div style="background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:8px 14px;font-family:var(--mono);font-size:.75rem;">
      <div style="color:var(--cyan2);text-transform:uppercase">${t}</div>
      <div style="font-size:1.2rem;color:var(--text);font-weight:700">${n}</div>
    </div>`).join('')||'<div style="color:var(--muted);font-family:var(--mono);font-size:.8rem;">No IoCs found. Run extraction first.</div>';

  // Rule cards grid
  const grid=document.getElementById('rulesGrid');
  grid.innerHTML='';
  if(!iocs.length){
    grid.innerHTML='<div style="color:var(--muted);font-family:var(--mono);font-size:.8rem;grid-column:1/-1;text-align:center;padding:30px;">No rules to display. Extract IoCs first.</div>';
    return;
  }
  iocs.forEach(i=>{
    const card=document.createElement('div');
    card.className='rule-card';
    card.innerHTML=`
      <div class="rule-card-header">
        <span><span class="badge badge-ok" style="font-size:.6rem">${i.ioc_type.toUpperCase()}</span> &nbsp;<span style="color:var(--cyan2)">${i.ioc_value.slice(0,40)}</span></span>
        <span style="color:var(--muted);font-size:.6rem">#${i.session_id} ${i.approved?'<span style="color:var(--green)">✓</span>':''}</span>
      </div>
      <div style="font-size:.6rem;color:var(--muted);font-family:var(--mono);margin-bottom:4px;text-transform:uppercase;letter-spacing:.08em;">YARA:</div>
      <pre>${(i.yara_rule||'N/A').slice(0,300)}${i.yara_rule&&i.yara_rule.length>300?' ...(truncated)':''}</pre>
      <div style="font-size:.6rem;color:var(--muted);font-family:var(--mono);margin:8px 0 4px;text-transform:uppercase;letter-spacing:.08em;">SURICATA:</div>
      <pre style="height:60px">${i.suricata_rule||'N/A'}</pre>
      <div style="margin-top:8px;display:flex;gap:6px;">
        <button class="btn btn-muted" style="font-size:.65rem;padding:3px 10px" onclick="showRules(${i.id})">EXPAND</button>
        <button class="btn btn-cyan" style="font-size:.65rem;padding:3px 10px" onclick="downloadSingleRule(${i.id})">&#8595;</button>
        ${!i.approved?`<button class="btn btn-green" style="font-size:.65rem;padding:3px 10px" onclick="approveIoC(${i.id});setTimeout(loadRules,500)">APPROVE</button>`:''}
      </div>`;
    grid.appendChild(card);
  });
}

async function downloadAllRules(){
  toast('Downloading all rules...');
  window.location='/api/download_all_rules';
}

// ── MISP Export Modal (choose & download) ─────────────────────────────────────
async function openMISPModal(){
  const iocs=await fetch('/api/iocs').then(r=>r.json());
  const approved=iocs.filter(i=>i.approved);
  const pending=iocs.filter(i=>!i.approved);

  const typeCount={};
  approved.forEach(i=>{typeCount[i.ioc_type]=(typeCount[i.ioc_type]||0)+1;});

  const summaryHTML=Object.entries(typeCount).map(([t,n])=>`
    <div class="misp-sum-box"><div class="n">${n}</div><div class="t">${t}</div></div>`).join('');

  const iocRows=iocs.map(i=>`
    <div class="misp-ioc-row">
      <input type="checkbox" id="mc_${i.id}" ${i.approved?'checked':''} value="${i.id}">
      <span class="badge badge-ok" style="font-size:.6rem">${i.ioc_type.toUpperCase()}</span>
      <span style="color:var(--cyan2);flex:1;word-break:break-all">${i.ioc_value}</span>
      <span style="color:var(--muted);font-size:.7rem">#${i.session_id}</span>
      ${i.approved?'<span style="color:var(--green);font-size:.7rem">✓ APPROVED</span>':'<span style="color:var(--muted);font-size:.7rem">PENDING</span>'}
    </div>`).join('');

  document.getElementById('mispModalContent').innerHTML=`
    <!-- TOP ACTION BUTTONS always visible -->
    <div style="display:flex;gap:10px;margin-bottom:16px;padding:12px;background:rgba(0,212,255,.05);border:1px solid rgba(0,212,255,.2);border-radius:6px;flex-wrap:wrap;align-items:center;">
      <span style="font-size:.7rem;font-family:var(--mono);color:var(--cyan);text-transform:uppercase;letter-spacing:.1em;flex:1;min-width:120px;">Export Actions</span>
      <button class="btn btn-green" style="font-size:.85rem;padding:8px 18px;" onclick="doMISPExport('pdf')">&#128196; Download PDF Report</button>
      <button class="btn btn-cyan" style="font-size:.85rem;padding:8px 18px;" onclick="doMISPExport('json')">&#8599; Download MISP JSON</button>
      <button class="btn btn-muted" style="font-size:.85rem;padding:8px 18px;" onclick="doApproveSelected()">&#10003; Approve Selected</button>
    </div>
    <div id="mispExportStatus" style="margin-bottom:10px;font-family:var(--mono);font-size:.75rem;color:var(--muted);"></div>
    <!-- Summary -->
    <div style="margin-bottom:12px;">
      <div style="font-size:.7rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:10px;">Approved IoCs Summary (${approved.length} approved, ${pending.length} pending)</div>
      <div class="misp-summary">${summaryHTML||'<div style="color:var(--muted);font-size:.8rem;font-family:var(--mono);">No approved IoCs yet. Approve some first.</div>'}</div>
    </div>
    <div style="font-size:.7rem;font-family:var(--mono);color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:8px;">
      Select IoCs to include in export:
      <button class="btn btn-muted" style="font-size:.65rem;padding:2px 8px;margin-left:10px" onclick="toggleAll(true)">ALL</button>
      <button class="btn btn-muted" style="font-size:.65rem;padding:2px 8px;margin-left:4px" onclick="toggleAll(false)">NONE</button>
      <button class="btn btn-muted" style="font-size:.65rem;padding:2px 8px;margin-left:4px" onclick="toggleApproved()">APPROVED ONLY</button>
    </div>
    <div class="misp-ioc-list">${iocRows||'<div style="color:var(--muted);font-family:var(--mono);font-size:.8rem;text-align:center;padding:20px;">No IoCs found. Run extraction first.</div>'}</div>`;

  document.getElementById('mispModalBg').classList.add('open');
}

function toggleAll(on){
  document.querySelectorAll('#mispModalContent input[type=checkbox]').forEach(c=>c.checked=on);
}
function toggleApproved(){
  document.querySelectorAll('#mispModalContent input[type=checkbox]').forEach(c=>{
    const row=c.closest('.misp-ioc-row');
    c.checked=row&&row.querySelector('.badge-ok')!==null;
  });
}
function getSelectedIds(){
  return [...document.querySelectorAll('#mispModalContent input[type=checkbox]:checked')].map(c=>parseInt(c.value));
}

async function doApproveSelected(){
  const ids=getSelectedIds();
  if(!ids.length){toast('Select at least one IoC',false);return;}
  let done=0;
  for(const id of ids){
    const r=await fetch(`/api/iocs/${id}/approve`,{method:'POST'});
    const d=await r.json();
    if(d.ok)done++;
  }
  toast(`${done} IoC(s) approved`);
  addLog(`Approved ${done} IoCs from MISP modal.`);
  openMISPModal(); loadStats();
}

async function doMISPExport(format){
  const ids=getSelectedIds();
  const statusEl=document.getElementById('mispExportStatus');
  if(!ids.length){toast('Select at least one IoC',false);return;}
  statusEl.textContent='Generating export...';
  const r=await fetch('/api/export_misp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids,format})});
  const d=await r.json();
  if(d.ok){
    const pdfNote=d.pdf_error?` (PDF warning: ${d.pdf_error})`:'';
    statusEl.textContent=`Export ready — ${d.attributes} attributes.${pdfNote}`;
    toast(`Export ready — ${d.attributes} attributes`);
    addLog(`MISP ${format.toUpperCase()} export: ${d.attributes} attributes.`);
    setTimeout(()=>{ window.location=format==='pdf'?'/api/download_misp_pdf':'/api/download_misp'; },400);
  } else {
    statusEl.innerHTML=`<span style="color:var(--red)">${d.error||'Export failed'}</span>`;
    toast(d.error||'Export failed',false);
  }
}

// ── Decoys ─────────────────────────────────────────────────────────────────────
const PORT_NAMES={21:'FTP',23:'Telnet',3306:'MySQL',5900:'VNC',8080:'HTTP-Alt'};
async function loadDecoys(){
  const r=await fetch('/api/decoy_events'); const rows=await r.json();
  const tbody=document.getElementById('decoyBody');
  tbody.innerHTML='';
  if(!rows.length){
    tbody.innerHTML='<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:30px;font-family:var(--mono);">NO DECOY EVENTS — TRIGGERED BY HIGHLY_SUSPICIOUS SESSIONS</td></tr>';
    return;
  }
  rows.forEach(d=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td style="color:var(--muted)">${d.id}</td>
      <td><code>#${d.session_id}</code></td>
      <td style="color:var(--orange)">${d.port}</td>
      <td><span class="badge badge-s">${PORT_NAMES[d.port]||'TCP'}</span></td>
      <td style="color:var(--muted)">${d.spawned_at?.slice(0,19)||''}</td>`;
    tbody.appendChild(tr);
  });
}

// ── Auto refresh ───────────────────────────────────────────────────────────────
setInterval(loadStats,15000);

// ── Init ───────────────────────────────────────────────────────────────────────
loadCharts();
addLog('Neuro-Trap dashboard online.');
addLog('All modules active. Monitoring port 2222.');
</script>
</body>
</html>"""


# ═══════════════════════════════════════════════════════════════════════════════
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    return render_template_string(DASHBOARD_HTML)

@app.route("/api/stats")
def api_stats():
    conn = get_db()
    try:    total      = conn.execute("SELECT COUNT(*) FROM attacks").fetchone()[0]
    except: total = 0
    try:    highly     = conn.execute("SELECT COUNT(*) FROM attacks WHERE risk_label='HIGHLY_SUSPICIOUS'").fetchone()[0]
    except: highly = 0
    try:    suspicious = conn.execute("SELECT COUNT(*) FROM attacks WHERE risk_label='SUSPICIOUS'").fetchone()[0]
    except: suspicious = 0
    try:    normal     = conn.execute("SELECT COUNT(*) FROM attacks WHERE risk_label='NORMAL'").fetchone()[0]
    except: normal = 0
    try:    iocs = conn.execute("SELECT COUNT(*) FROM iocs").fetchone()[0]
    except: iocs = 0
    conn.close()
    return jsonify(total=total, highly=highly, suspicious=suspicious, normal=normal, iocs=iocs)

@app.route("/api/sessions")
def api_sessions():
    label=request.args.get("label",""); ip=request.args.get("ip","")
    query="SELECT * FROM attacks WHERE 1=1"; params=[]
    if label: query+=" AND risk_label=?"; params.append(label)
    if ip:    query+=" AND src_ip LIKE ?"; params.append(f"%{ip}%")
    query+=" ORDER BY id DESC LIMIT 500"
    conn=get_db(); rows=[dict(r) for r in conn.execute(query,params).fetchall()]; conn.close()
    return jsonify(rows)

@app.route("/api/sessions/<int:sid>")
def api_session_detail(sid):
    conn=get_db(); row=conn.execute("SELECT * FROM attacks WHERE id=?",(sid,)).fetchone(); conn.close()
    return jsonify(dict(row)) if row else (jsonify(error="Not found"),404)

@app.route("/api/run_ml", methods=["POST"])
def api_run_ml():
    results=run_ml_analysis(); return jsonify(scored=len(results),results=results)

@app.route("/api/run_extraction", methods=["POST"])
def api_run_extraction():
    iocs=run_extraction(); return jsonify(iocs_found=len(iocs))

@app.route("/api/export_csv")
def api_export_csv():
    conn=get_db(); rows=conn.execute("SELECT * FROM attacks ORDER BY id DESC").fetchall(); conn.close()
    output=io.StringIO(); writer=csv.writer(output)
    writer.writerow(["id","src_ip","src_port","dst_ip","dst_port","timestamp","duration_sec","bytes_recv","commands","ml_score","risk_label"])
    for r in rows:
        writer.writerow([r["id"],r["src_ip"],r["src_port"],r["dst_ip"],r["dst_port"],r["timestamp"],
                         r["duration_sec"],r["bytes_recv"],(r["commands"]or"").replace("\n"," | "),r["ml_score"],r["risk_label"]])
    output.seek(0)
    filename=f"neuro_trap_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return send_file(io.BytesIO(output.getvalue().encode()),mimetype="text/csv",as_attachment=True,download_name=filename)

@app.route("/api/iocs")
def api_iocs():
    ioc_type=request.args.get("type",""); approved=request.args.get("approved","")
    query="SELECT * FROM iocs WHERE 1=1"; params=[]
    if ioc_type: query+=" AND ioc_type=?"; params.append(ioc_type)
    if approved!="": query+=" AND approved=?"; params.append(int(approved))
    query+=" ORDER BY id DESC LIMIT 1000"
    conn=get_db()
    try:    rows=[dict(r) for r in conn.execute(query,params).fetchall()]
    except: rows=[]
    conn.close(); return jsonify(rows)

@app.route("/api/iocs/<int:ioc_id>")
def api_ioc_detail(ioc_id):
    conn=get_db(); row=conn.execute("SELECT * FROM iocs WHERE id=?",(ioc_id,)).fetchone(); conn.close()
    return jsonify(dict(row)) if row else (jsonify(error="Not found"),404)

@app.route("/api/iocs/<int:ioc_id>/approve", methods=["POST"])
def api_approve_ioc(ioc_id):
    conn=get_db(); conn.execute("UPDATE iocs SET approved=1 WHERE id=?",(ioc_id,)); conn.commit(); conn.close()
    logger.info("IoC #%d approved.",ioc_id); return jsonify(ok=True)

@app.route("/api/iocs/<int:ioc_id>/download_rules")
def api_download_rules(ioc_id):
    conn=get_db(); row=conn.execute("SELECT * FROM iocs WHERE id=?",(ioc_id,)).fetchone(); conn.close()
    if not row: return jsonify(error="Not found"),404
    row=dict(row)
    content=f"// Neuro-Trap Detection Rules — IoC #{ioc_id}\n"
    content+=f"// Type: {row['ioc_type']}  Value: {row['ioc_value']}\n"
    content+=f"// Session: #{row['session_id']}  Extracted: {row['extracted_at']}\n\n"
    content+=f"// === YARA RULE ===\n{row['yara_rule'] or 'N/A'}\n\n"
    content+=f"// === SURICATA RULE ===\n{row['suricata_rule'] or 'N/A'}\n"
    fn=f"rules_ioc_{ioc_id}_{row['ioc_type']}.txt"
    return send_file(io.BytesIO(content.encode()),mimetype="text/plain",as_attachment=True,download_name=fn)

@app.route("/api/download_all_rules")
def api_download_all_rules():
    conn=get_db()
    try: rows=[dict(r) for r in conn.execute("SELECT * FROM iocs ORDER BY id DESC").fetchall()]
    except: rows=[]
    conn.close()
    lines=["// Neuro-Trap — All Detection Rules Export","// Generated: "+datetime.utcnow().isoformat(),"//"+("="*60),""]
    for row in rows:
        lines.append(f"// IoC #{row['id']} | {row['ioc_type'].upper()} | {row['ioc_value']} | Session #{row['session_id']}")
        lines.append(f"// Approved: {'YES' if row['approved'] else 'NO'}")
        lines.append("// --- YARA ---")
        lines.append(row['yara_rule'] or '/* N/A */')
        lines.append("// --- SURICATA ---")
        lines.append(row['suricata_rule'] or '# N/A')
        lines.append("")
    content="\n".join(lines)
    fn=f"neuro_trap_all_rules_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.txt"
    return send_file(io.BytesIO(content.encode()),mimetype="text/plain",as_attachment=True,download_name=fn)

@app.route("/api/export_misp", methods=["POST"])
def api_export_misp():
    """Export MISP as JSON + build PDF. Accepts optional {ids:[...], format:'pdf'|'json'}"""
    data=request.get_json(silent=True) or {}
    selected_ids=data.get("ids",[])
    fmt=data.get("format","pdf")

    # Get IoCs — filtered by selected IDs if provided
    conn=get_db()
    try:
        if selected_ids:
            placeholders=",".join("?"*len(selected_ids))
            rows=[dict(r) for r in conn.execute(
                f"SELECT i.*,a.src_ip,a.timestamp as session_time,a.risk_label FROM iocs i JOIN attacks a ON a.id=i.session_id WHERE i.id IN ({placeholders})",
                selected_ids).fetchall()]
        else:
            rows=[dict(r) for r in conn.execute(
                "SELECT i.*,a.src_ip,a.timestamp as session_time,a.risk_label FROM iocs i JOIN attacks a ON a.id=i.session_id WHERE i.approved=1").fetchall()]
    except Exception as e:
        conn.close(); return jsonify(ok=False,error=str(e))
    conn.close()

    if not rows:
        # Try all iocs as fallback
        try:
            rows=[dict(r) for r in get_db().execute(
                "SELECT i.*,a.src_ip,a.timestamp as session_time,a.risk_label FROM iocs i JOIN attacks a ON a.id=i.session_id LIMIT 200").fetchall()]
        except: pass
    if not rows:
        return jsonify(ok=False,error="No IoCs found. Run Extract IoCs first, then try again.")

    # Build MISP JSON (always save)
    result=export_approved_iocs()

    # Build PDF
    pdf_error = None
    try:
        _build_misp_pdf(rows)
    except Exception as e:
        logger.warning("PDF build failed: %s", e)
        pdf_error = str(e)

    return jsonify(ok=True, attributes=len(rows), pdf_error=pdf_error)

def _build_misp_pdf(rows):
    """Generate a professional PDF report from IoC rows using reportlab."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
        from reportlab.lib.enums import TA_LEFT, TA_CENTER
    except ImportError:
        # Fallback: plain text PDF-like file
        _build_misp_txt(rows)
        return

    import os as _os; path=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),"neuro_trap_misp_export.pdf")
    doc=SimpleDocTemplate(path,pagesize=A4,
        rightMargin=20*mm,leftMargin=20*mm,topMargin=20*mm,bottomMargin=20*mm)

    styles=getSampleStyleSheet()
    dark=(0.02,0.04,0.07)
    cyan_c=colors.HexColor('#00d4ff')
    red_c=colors.HexColor('#ff2d55')
    orange_c=colors.HexColor('#ff6b2b')
    green_c=colors.HexColor('#00ff88')
    grey_c=colors.HexColor('#6ba3be')

    title_style=ParagraphStyle('title',fontSize=20,leading=26,textColor=cyan_c,spaceAfter=4,fontName='Helvetica-Bold')
    sub_style=ParagraphStyle('sub',fontSize=9,leading=14,textColor=grey_c,spaceAfter=12,fontName='Helvetica')
    section_style=ParagraphStyle('sec',fontSize=11,leading=16,textColor=cyan_c,spaceBefore=14,spaceAfter=6,fontName='Helvetica-Bold')
    body_style=ParagraphStyle('body',fontSize=8,leading=12,textColor=colors.HexColor('#c8e8f5'),fontName='Helvetica')
    mono_style=ParagraphStyle('mono',fontSize=7,leading=10,textColor=colors.HexColor('#00ffcc'),fontName='Courier',spaceAfter=4)

    story=[]

    # Header
    story.append(Paragraph("NEURO-TRAP THREAT INTELLIGENCE PLATFORM",title_style))
    story.append(Paragraph(f"MISP Export Report — Generated {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}",sub_style))
    story.append(HRFlowable(width="100%",thickness=1,color=cyan_c,spaceAfter=10))

    # Summary stats
    type_counts={}
    for r in rows:
        type_counts[r['ioc_type']]=type_counts.get(r['ioc_type'],0)+1
    approved_count=sum(1 for r in rows if r.get('approved'))

    summary_data=[['METRIC','VALUE'],
                  ['Total IoCs',str(len(rows))],
                  ['Approved',str(approved_count)],
                  ['Pending',str(len(rows)-approved_count)],
                  ['IoC Types',str(len(type_counts))],
                  ['Export Date',datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')]]
    t=Table(summary_data,colWidths=[80*mm,80*mm])
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#0a3d5c')),
        ('TEXTCOLOR',(0,0),(-1,0),cyan_c),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('FONTSIZE',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#071520'),colors.HexColor('#050f1a')]),
        ('TEXTCOLOR',(0,1),(-1,-1),colors.HexColor('#c8e8f5')),
        ('GRID',(0,0),(-1,-1),0.5,colors.HexColor('#0d2d45')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,-1),5),
        ('BOTTOMPADDING',(0,0),(-1,-1),5),
    ]))
    story.append(t)
    story.append(Spacer(1,10))

    # Type breakdown table
    story.append(Paragraph("IOC TYPE BREAKDOWN",section_style))
    type_rows=[['TYPE','COUNT']]+[[k.upper(),str(v)] for k,v in sorted(type_counts.items(),key=lambda x:-x[1])]
    t2=Table(type_rows,colWidths=[80*mm,80*mm])
    t2.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#0a3d5c')),
        ('TEXTCOLOR',(0,0),(-1,0),cyan_c),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('FONTSIZE',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#071520'),colors.HexColor('#050f1a')]),
        ('TEXTCOLOR',(0,1),(-1,-1),colors.HexColor('#c8e8f5')),
        ('GRID',(0,0),(-1,-1),0.5,colors.HexColor('#0d2d45')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,-1),5),
        ('BOTTOMPADDING',(0,0),(-1,-1),5),
    ]))
    story.append(t2)
    story.append(Spacer(1,10))

    # IoC Details table
    story.append(Paragraph("INDICATORS OF COMPROMISE — DETAIL",section_style))
    ioc_header=[['#','SESSION','TYPE','VALUE','RISK','EXTRACTED','STATUS']]
    ioc_rows=[]
    for r in rows:
        status='APPROVED' if r.get('approved') else 'PENDING'
        val=str(r['ioc_value'])
        if len(val)>40: val=val[:37]+'...'
        ioc_rows.append([
            str(r['id']),
            f"#{r['session_id']}",
            r['ioc_type'].upper(),
            val,
            r.get('risk_label','—'),
            str(r.get('extracted_at',''))[:16],
            status
        ])
    t3=Table(ioc_header+ioc_rows,colWidths=[10*mm,18*mm,22*mm,52*mm,28*mm,28*mm,18*mm])
    row_count=len(ioc_rows)
    ts=[
        ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#0a3d5c')),
        ('TEXTCOLOR',(0,0),(-1,0),cyan_c),
        ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
        ('FONTSIZE',(0,0),(-1,-1),7),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#071520'),colors.HexColor('#050f1a')]),
        ('TEXTCOLOR',(0,1),(-1,-1),colors.HexColor('#c8e8f5')),
        ('GRID',(0,0),(-1,-1),0.4,colors.HexColor('#0d2d45')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('TOPPADDING',(0,0),(-1,-1),4),
        ('BOTTOMPADDING',(0,0),(-1,-1),4),
    ]
    # Colour HIGHLY_SUSPICIOUS rows red
    for idx,r in enumerate(rows,1):
        if r.get('risk_label')=='HIGHLY_SUSPICIOUS':
            ts.append(('TEXTCOLOR',(4,idx),(4,idx),red_c))
        elif r.get('risk_label')=='SUSPICIOUS':
            ts.append(('TEXTCOLOR',(4,idx),(4,idx),orange_c))
        if r.get('approved'):
            ts.append(('TEXTCOLOR',(6,idx),(6,idx),green_c))
    t3.setStyle(TableStyle(ts))
    story.append(t3)
    story.append(Spacer(1,10))

    # YARA + Suricata rules section
    story.append(HRFlowable(width="100%",thickness=0.5,color=colors.HexColor('#0d2d45'),spaceAfter=6))
    story.append(Paragraph("DETECTION RULES (YARA & SURICATA)",section_style))
    for r in rows[:30]:   # cap at 30 to keep PDF manageable
        story.append(Paragraph(
            f"<b>IoC #{r['id']} — {r['ioc_type'].upper()}: {r['ioc_value']}</b>",
            ParagraphStyle('rh',fontSize=8,leading=12,textColor=cyan_c,fontName='Helvetica-Bold',spaceBefore=8,spaceAfter=3)))
        if r.get('yara_rule'):
            story.append(Paragraph("YARA:",ParagraphStyle('rl',fontSize=7,leading=10,textColor=grey_c,fontName='Helvetica-Bold')))
            yara_text=r['yara_rule'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
            story.append(Paragraph(yara_text,mono_style))
        if r.get('suricata_rule'):
            story.append(Paragraph("SURICATA:",ParagraphStyle('rl2',fontSize=7,leading=10,textColor=grey_c,fontName='Helvetica-Bold')))
            sur_text=r['suricata_rule'].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
            story.append(Paragraph(sur_text,mono_style))

    story.append(Spacer(1,8))
    story.append(HRFlowable(width="100%",thickness=1,color=cyan_c))
    story.append(Paragraph("END OF REPORT — NEURO-TRAP v2.1 // CONFIDENTIAL // TLP:AMBER",
        ParagraphStyle('footer',fontSize=7,leading=12,textColor=grey_c,fontName='Helvetica',spaceBefore=6,alignment=TA_CENTER)))

    doc.build(story)
    logger.info("PDF export saved to %s",path)

def _build_misp_txt(rows):
    """Fallback plain-text export when reportlab is not installed."""
    lines=["="*70,"NEURO-TRAP THREAT INTELLIGENCE PLATFORM","MISP Export Report","Generated: "+datetime.utcnow().isoformat(),"="*70,""]
    for r in rows:
        lines.append(f"[IoC #{r['id']}] {r['ioc_type'].upper()}: {r['ioc_value']}")
        lines.append(f"  Session: #{r['session_id']} | Risk: {r.get('risk_label','?')} | Approved: {'YES' if r.get('approved') else 'NO'}")
        if r.get('yara_rule'): lines.append("  YARA: "+r['yara_rule'][:120]+"...")
        if r.get('suricata_rule'): lines.append("  SURICATA: "+r['suricata_rule'])
        lines.append("")
    import os as _os2; _txt_path=_os2.path.join(_os2.path.dirname(_os2.path.abspath(__file__)),"neuro_trap_misp_export.pdf")
    with open(_txt_path,"w") as f:
        f.write("\n".join(lines))

@app.route("/api/download_misp_pdf")
def api_download_misp_pdf():
    import os
    base = os.path.dirname(os.path.abspath(__file__))
    for fn,mime,dname in [
        ("neuro_trap_misp_export.pdf","application/pdf","neuro_trap_report.pdf"),
        ("neuro_trap_misp_export.txt","text/plain","neuro_trap_report.txt")]:
        full = os.path.join(base,fn)
        if os.path.exists(full):
            return send_file(full,mimetype=mime,as_attachment=True,download_name=dname)
    return jsonify(error="Export file not found. Run Export MISP first."),404

@app.route("/api/download_misp")
def api_download_misp():
    try:
        return send_file("neuro_trap_misp_export.json",mimetype="application/json",
                         as_attachment=True,download_name="neuro_trap_misp_export.json")
    except FileNotFoundError:
        return jsonify(error="Export file not found."),404

@app.route("/api/decoy_events")
def api_decoy_events():
    conn=get_db()
    try:    rows=[dict(r) for r in conn.execute("SELECT * FROM decoy_events ORDER BY id DESC LIMIT 200").fetchall()]
    except: rows=[]
    conn.close(); return jsonify(rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000,debug=False)