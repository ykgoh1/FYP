# Neuro-Trap — Setup & Run Guide

## Project Files
```
neuro_trap/
├── simple_honeypot.py      # Module 1 – TCP listener
├── behaviour_ml.py         # Module 2 – ML engine
├── ioc_extractor.py        # Module 3 – IoC extractor
├── decoy_orchestrator.py   # Module 4 – Decoy ports
├── app.py                  # Module 5 – Flask dashboard
├── misp_mock.py            # Module 6 – MISP export
└── requirements.txt
```

---

## Step 1 — Install Python
Download Python 3.10 or newer from https://www.python.org/downloads/
During install tick **"Add Python to PATH"**

---

## Step 2 — Install Libraries
Open **Command Prompt** or **Terminal** inside the neuro_trap folder:
```
pip install -r requirements.txt
```

---

## Step 3 — Run Each Module

### Terminal 1 — Start Honeypot (captures attacker connections)
```
python simple_honeypot.py
```
Listens on **port 2222**. Creates `neuro_trap.db` automatically.

### Terminal 2 — Start Decoy Orchestrator (spawns fake services)
```
python decoy_orchestrator.py
```
Polls DB every 10s. Spawns decoys on ports 21, 23, 3306, 5900, 8080 when HIGHLY_SUSPICIOUS detected.

### Terminal 3 — Start Flask Dashboard (web GUI)
```
python app.py
```
Open browser → **http://localhost:5000**

---

## Step 4 — Using the Dashboard

| Button | What it does |
|--------|-------------|
| Run ML Analysis | Scores all unscored sessions |
| Extract IoCs | Extracts IPs, domains, hashes from payloads |
| CSV | Downloads all sessions as CSV |
| Approve (IoCs tab) | Marks IoC for MISP export |
| Export MISP JSON | Downloads MISP-compatible JSON file |

---

## Step 5 — Test Without Real Attacker
Open another terminal and connect manually:
```
# Windows
telnet localhost 2222

# Linux / Mac
nc localhost 2222
```
Type some commands (ls, whoami, wget http://evil.com) then close.
Go to dashboard → click **Run ML Analysis** → click **Extract IoCs**.

---

## Ports Used
| Port | Module |
|------|--------|
| 2222 | Honeypot (main) |
| 5000 | Flask Dashboard |
| 21   | Decoy FTP |
| 23   | Decoy Telnet |
| 3306 | Decoy MySQL |
| 5900 | Decoy VNC |
| 8080 | Decoy HTTP |

> **Note:** Run as Administrator (Windows) or sudo (Linux) if ports below 1024 are blocked.
