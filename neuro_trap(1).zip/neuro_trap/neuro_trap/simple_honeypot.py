"""
simple_honeypot.py - Neuro-Trap Honeypot Engine
Module 1: Binds to a configurable TCP port, captures all incoming
          attacker sessions and stores them in SQLite database.
"""

import socket
import sqlite3
import threading
import logging
import time
import re
from datetime import datetime, timezone

# ── Configuration ────────────────────────────────────────────────────────────
DB_PATH      = "neuro_trap.db"
BIND_HOST    = "0.0.0.0"
BIND_PORT    = 2222          # Main honeypot port
BUFFER_SIZE  = 4096
SESSION_TIMEOUT = 30         # seconds before idle session closes

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [HONEYPOT] %(message)s"
)
logger = logging.getLogger(__name__)


# ── Database Initialisation ───────────────────────────────────────────────────
def init_db():
    """Create the attacks table if it does not already exist."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS attacks (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            src_ip        TEXT    NOT NULL,
            src_port      INTEGER NOT NULL,
            dst_ip        TEXT    NOT NULL,
            dst_port      INTEGER NOT NULL,
            timestamp     TEXT    NOT NULL,
            duration_sec  REAL    DEFAULT 0,
            bytes_recv    INTEGER DEFAULT 0,
            commands      TEXT    DEFAULT '',
            payload_raw   TEXT    DEFAULT '',
            ml_score      REAL    DEFAULT NULL,
            risk_label    TEXT    DEFAULT 'UNSCORED',
            ioc_approved  INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()
    logger.info("Database initialised at %s", DB_PATH)


# ── Session Logging ───────────────────────────────────────────────────────────
def log_session(src_ip, src_port, dst_ip, dst_port,
                timestamp, duration, bytes_recv, commands, payload_raw):
    """Insert one attacker session record into SQLite."""
    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()
    cur.execute("""
        INSERT INTO attacks
            (src_ip, src_port, dst_ip, dst_port, timestamp,
             duration_sec, bytes_recv, commands, payload_raw)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (src_ip, src_port, dst_ip, dst_port, timestamp,
          duration, bytes_recv, commands, payload_raw))
    conn.commit()
    session_id = cur.lastrowid
    conn.close()
    logger.info("Session #%d logged  src=%s:%d  bytes=%d  duration=%.1fs",
                session_id, src_ip, src_port, bytes_recv, duration)
    return session_id


# ── Simulated Banner (pre-configured only — no real service exposed) ──────────
FAKE_BANNER = (
    b"SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6\r\n"
)

FAKE_RESPONSES = {
    b"ls"     : b"bin  etc  home  usr  var\r\n",
    b"whoami" : b"root\r\n",
    b"id"     : b"uid=0(root) gid=0(root) groups=0(root)\r\n",
    b"pwd"    : b"/root\r\n",
    b"uname"  : b"Linux honeypot 5.15.0 #1 SMP x86_64 GNU/Linux\r\n",
}


def strip_protocol_bytes(data: bytes) -> bytes:
    """
    Strip Telnet IAC sequences (0xFF prefix negotiation bytes) and
    other non-printable control bytes from attacker input so that
    commands are stored as clean ASCII text.
    Telnet negotiation: FF <cmd-byte> <option-byte>  (3 bytes each)

    FIX: Was stripping too aggressively. Now only removes actual
    Telnet negotiation sequences, keeps printable ASCII + CR/LF.
    """
    # Remove IAC (0xFF) negotiation sequences: FF xx yy (3 bytes each)
    cleaned = re.sub(b'\xff[\xfb-\xfe].', b'', data)
    # Remove standalone IAC bytes
    cleaned = cleaned.replace(b'\xff', b'')
    # Remove backspace/delete chars that can corrupt cmd storage
    cleaned = re.sub(b'[\x08\x7f]', b'', cleaned)
    # Keep printable ASCII + newline/carriage-return/tab
    cleaned = bytes(b for b in cleaned if b >= 0x20 or b in (0x09, 0x0a, 0x0d))
    return cleaned


def get_fake_response(command: bytes) -> bytes:
    """Return a pre-configured fake response. Never executes attacker input."""
    cmd = strip_protocol_bytes(command).strip().lower()
    for key, resp in FAKE_RESPONSES.items():
        if key in cmd:
            return resp
    return b"command not found\r\n"


# ── Per-connection Handler ────────────────────────────────────────────────────
def handle_connection(client_sock: socket.socket, addr: tuple, server_ip: str, port: int):
    """Handle one attacker TCP connection in its own thread."""
    src_ip, src_port = addr
    timestamp   = datetime.now(timezone.utc).isoformat()
    start_time  = time.time()
    commands    = []
    raw_chunks  = []
    total_bytes = 0

    logger.info("New connection  src=%s:%d", src_ip, src_port)

    try:
        client_sock.settimeout(SESSION_TIMEOUT)
        client_sock.sendall(FAKE_BANNER)

        buffer = b""
        while True:
            try:
                data = client_sock.recv(BUFFER_SIZE)
                if not data:
                    break
                total_bytes += len(data)
                raw_chunks.append(data.decode(errors="replace"))

                # Buffer data and process line by line (handles telnet line-mode)
                buffer += data
                while b'\n' in buffer or b'\r' in buffer:
                    # Split on first newline
                    for sep in [b'\r\n', b'\n', b'\r']:
                        if sep in buffer:
                            line, buffer = buffer.split(sep, 1)
                            clean_line = strip_protocol_bytes(line)
                            cmd_text = clean_line.decode(errors="replace").strip()
                            if cmd_text:
                                commands.append(cmd_text)
                                logger.info("  CMD from %s: %r", src_ip, cmd_text[:120])
                            response = get_fake_response(line + sep)
                            client_sock.sendall(response)
                            break
                    else:
                        break

            except socket.timeout:
                logger.info("Session timeout  src=%s:%d", src_ip, src_port)
                break
    except Exception as exc:
        logger.warning("Connection error  src=%s:%d  %s", src_ip, src_port, exc)
    finally:
        client_sock.close()

    duration    = round(time.time() - start_time, 2)
    commands_str = "\n".join(commands)
    payload_str  = "".join(raw_chunks)

    log_session(
        src_ip, src_port, server_ip, port,
        timestamp, duration, total_bytes,
        commands_str, payload_str
    )


# ── Main Listener ─────────────────────────────────────────────────────────────
def start_honeypot(host: str = BIND_HOST, port: int = BIND_PORT):
    """Bind to port and accept connections indefinitely."""
    init_db()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(50)
    logger.info("Honeypot listening on %s:%d", host, port)

    try:
        while True:
            client_sock, addr = server.accept()
            t = threading.Thread(
                target=handle_connection,
                args=(client_sock, addr, host, port),
                daemon=True
            )
            t.start()
    except KeyboardInterrupt:
        logger.info("Honeypot shutting down.")
    finally:
        server.close()


if __name__ == "__main__":
    start_honeypot()