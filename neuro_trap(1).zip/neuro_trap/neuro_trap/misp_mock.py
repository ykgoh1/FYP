"""
misp_mock.py - Neuro-Trap MISP Export Pipeline
Module 6: Converts analyst-approved IoCs from SQLite into a
          MISP-compatible JSON event structure ready for import.
"""

import sqlite3
import json
import uuid
import logging
from datetime import datetime, timezone

# ── Configuration ─────────────────────────────────────────────────────────────
DB_PATH     = "neuro_trap.db"
OUTPUT_PATH = "neuro_trap_misp_export.json"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MISP EXPORT] %(message)s"
)
logger = logging.getLogger(__name__)

# ── MISP Type Mapping ─────────────────────────────────────────────────────────
MISP_TYPE_MAP = {
    "ip"           : "ip-dst",
    "domain"       : "domain",
    "url"          : "url",
    "md5"          : "md5",
    "sha256"       : "sha256",
    "cve"          : "vulnerability",
    "malicious_cmd": "text",
}

MISP_CATEGORY_MAP = {
    "ip"           : "Network activity",
    "domain"       : "Network activity",
    "url"          : "Network activity",
    "md5"          : "Artifacts dropped",
    "sha256"       : "Artifacts dropped",
    "cve"          : "External analysis",
    "malicious_cmd": "Artifacts dropped",
}


# ── Load Approved IoCs ────────────────────────────────────────────────────────
def load_approved_iocs() -> list:
    """Fetch all analyst-approved IoCs from the database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur  = conn.cursor()
    cur.execute("""
        SELECT i.id, i.session_id, i.ioc_type, i.ioc_value,
               i.yara_rule, i.suricata_rule, i.extracted_at,
               a.src_ip, a.timestamp as session_time, a.risk_label
        FROM   iocs i
        JOIN   attacks a ON a.id = i.session_id
        WHERE  i.approved = 1
        ORDER  BY i.id ASC
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


# ── Build MISP Attribute ──────────────────────────────────────────────────────
def build_misp_attribute(ioc: dict) -> dict:
    """Convert one IoC row into a MISP attribute object."""
    ioc_type = ioc["ioc_type"]
    return {
        "uuid"        : str(uuid.uuid4()),
        "type"        : MISP_TYPE_MAP.get(ioc_type, "text"),
        "category"    : MISP_CATEGORY_MAP.get(ioc_type, "External analysis"),
        "value"       : ioc["ioc_value"],
        "to_ids"      : True,
        "distribution": 0,
        "comment"     : (f"Extracted from honeypot session #{ioc['session_id']} "
                         f"| risk={ioc['risk_label']} "
                         f"| src_ip={ioc['src_ip']}"),
        "timestamp"   : ioc["extracted_at"],
    }


# ── Build MISP Event ──────────────────────────────────────────────────────────
def build_misp_event(iocs: list) -> dict:
    """Wrap all attributes into a single MISP event envelope."""
    attributes = [build_misp_attribute(i) for i in iocs]

    event = {
        "Event": {
            "uuid"        : str(uuid.uuid4()),
            "info"        : "Neuro-Trap Honeypot — Exported IoCs",
            "date"        : datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "threat_level_id": "2",    # Medium
            "analysis"    : "2",       # Completed
            "distribution": "0",       # Organisation only
            "Attribute"   : attributes,
            "Tag"         : [
                {"name": "neuro-trap"},
                {"name": "honeypot"},
                {"name": "tlp:amber"},
            ],
            "Org"         : {"name": "Neuro-Trap"},
            "timestamp"   : datetime.now(timezone.utc).isoformat(),
        }
    }
    return event


# ── Export Pipeline ───────────────────────────────────────────────────────────
def export_approved_iocs(output_path: str = OUTPUT_PATH) -> dict:
    """
    Full export pipeline:
      1. Load approved IoCs.
      2. Build MISP event JSON.
      3. Write to file.
    Returns the MISP event dict.
    """
    iocs = load_approved_iocs()

    if not iocs:
        logger.warning("No approved IoCs found. Approve some IoCs in the dashboard first.")
        return {}

    event = build_misp_event(iocs)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(event, f, indent=2, ensure_ascii=False)

    logger.info("Export saved to: %s  (%d attributes)", output_path, len(iocs))
    return event


# ── CLI entry point ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    result = export_approved_iocs()
    if result:
        attrs = result.get("Event", {}).get("Attribute", [])
        print(f"\n MISP export complete — {len(attrs)} attributes written to {OUTPUT_PATH}")
    else:
        print("\n Nothing to export. Approve IoCs in the dashboard first.")
