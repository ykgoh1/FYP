"""
ioc_extractor.py - Neuro-Trap IoC Extraction Subsystem
Module 3: Scans captured session payloads for Indicators of Compromise
          and generates YARA and Suricata rule templates for analyst review.
"""

import sqlite3
import re
import json
import logging
from datetime import datetime

# ── Configuration ─────────────────────────────────────────────────────────────
DB_PATH     = "neuro_trap.db"
IOC_DB_PATH = "neuro_trap.db"   # IoCs stored in same DB, separate table

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [IOC EXTRACTOR] %(message)s"
)
logger = logging.getLogger(__name__)

# ── Regex Patterns ─────────────────────────────────────────────────────────────
IP_PATTERN      = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
DOMAIN_PATTERN  = re.compile(
    r"\b(?:[a-zA-Z0-9-]+\.)+(?:com|net|org|io|ru|cn|top|xyz|tk|cc)\b"
)
URL_PATTERN     = re.compile(r"https?://[^\s\"'<>]+")
HASH_MD5        = re.compile(r"\b[0-9a-fA-F]{32}\b")
HASH_SHA256     = re.compile(r"\b[0-9a-fA-F]{64}\b")
CVE_PATTERN     = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)

# Suspicious command sequences
MALICIOUS_CMDS  = [
    "wget", "curl", "chmod +x", "/bin/bash", "/bin/sh",
    "nc -e", "ncat", "python -c", "perl -e", "ruby -e",
    "base64 -d", "echo | bash", "> /dev/null",
    "cat /etc/passwd", "cat /etc/shadow", "id ; whoami"
]


# ── DB Initialisation ─────────────────────────────────────────────────────────
def init_ioc_table():
    """Create the iocs table if it does not already exist."""
    conn = sqlite3.connect(IOC_DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS iocs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id  INTEGER NOT NULL,
            ioc_type    TEXT    NOT NULL,
            ioc_value   TEXT    NOT NULL,
            yara_rule   TEXT,
            suricata_rule TEXT,
            extracted_at  TEXT NOT NULL,
            approved    INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()


# ── Extraction Helpers ────────────────────────────────────────────────────────
def extract_iocs_from_payload(payload: str) -> list:
    """
    Run all regex patterns against payload text.
    Returns list of (ioc_type, ioc_value) tuples.
    """
    found = []

    for ip in set(IP_PATTERN.findall(payload)):
        # Skip private/loopback ranges
        if not (ip.startswith("127.") or ip.startswith("10.")
                or ip.startswith("192.168.") or ip == "0.0.0.0"):
            found.append(("ip", ip))

    for domain in set(DOMAIN_PATTERN.findall(payload)):
        found.append(("domain", domain))

    for url in set(URL_PATTERN.findall(payload)):
        found.append(("url", url))

    for md5 in set(HASH_MD5.findall(payload)):
        found.append(("md5", md5))

    for sha256 in set(HASH_SHA256.findall(payload)):
        found.append(("sha256", sha256))

    for cve in set(CVE_PATTERN.findall(payload)):
        found.append(("cve", cve))

    for cmd in MALICIOUS_CMDS:
        if cmd.lower() in payload.lower():
            found.append(("malicious_cmd", cmd))

    return found


# ── Rule Generators ───────────────────────────────────────────────────────────
def generate_yara_rule(ioc_type: str, ioc_value: str, session_id: int) -> str:
    """Generate a YARA rule template for the given IoC."""
    safe_val  = re.sub(r"[^a-zA-Z0-9_]", "_", ioc_value)[:40]
    rule_name = f"NeuropTrap_{ioc_type}_{safe_val}_{session_id}"

    if ioc_type in ("ip", "domain", "url", "malicious_cmd"):
        return f"""rule {rule_name}
{{
    meta:
        description = "Neuro-Trap auto-generated rule for {ioc_type}: {ioc_value}"
        session_id  = "{session_id}"
        generated   = "{datetime.utcnow().isoformat()}"
        author      = "Neuro-Trap"
    strings:
        $indicator = "{ioc_value}" ascii wide nocase
    condition:
        $indicator
}}"""

    elif ioc_type in ("md5", "sha256"):
        hash_kw = "md5" if ioc_type == "md5" else "sha256"
        return f"""rule {rule_name}
{{
    meta:
        description = "Neuro-Trap hash match: {ioc_value}"
        session_id  = "{session_id}"
        generated   = "{datetime.utcnow().isoformat()}"
    condition:
        {hash_kw} == "{ioc_value.lower()}"
}}"""

    return f"/* No YARA template for ioc_type={ioc_type} */"


def generate_suricata_rule(ioc_type: str, ioc_value: str, session_id: int) -> str:
    """Generate a Suricata/Snort rule template for the given IoC."""
    sid = 9000000 + session_id

    if ioc_type == "ip":
        return (f'alert tcp {ioc_value} any -> $HOME_NET any '
                f'(msg:"NeuropTrap - Suspicious IP {ioc_value} session {session_id}"; '
                f'sid:{sid}; rev:1;)')

    elif ioc_type == "domain":
        return (f'alert dns $HOME_NET any -> any 53 '
                f'(msg:"NeuropTrap - Suspicious domain {ioc_value} session {session_id}"; '
                f'dns.query; content:"{ioc_value}"; nocase; '
                f'sid:{sid}; rev:1;)')

    elif ioc_type == "url":
        safe = ioc_value.replace('"', '\\"')[:80]
        return (f'alert http $HOME_NET any -> $EXTERNAL_NET any '
                f'(msg:"NeuropTrap - Suspicious URL session {session_id}"; '
                f'http.uri; content:"{safe}"; nocase; '
                f'sid:{sid}; rev:1;)')

    elif ioc_type == "malicious_cmd":
        safe = ioc_value.replace('"', '\\"')
        return (f'alert tcp any any -> $HOME_NET 2222 '
                f'(msg:"NeuropTrap - Malicious command detected session {session_id}"; '
                f'content:"{safe}"; nocase; '
                f'sid:{sid}; rev:1;)')

    return f"# No Suricata template for ioc_type={ioc_type}"


# ── Store IoC ─────────────────────────────────────────────────────────────────
def store_ioc(session_id, ioc_type, ioc_value, yara_rule, suricata_rule):
    """Insert one IoC record into the iocs table."""
    conn = sqlite3.connect(IOC_DB_PATH)
    cur  = conn.cursor()
    # Avoid duplicates within same session
    cur.execute(
        "SELECT id FROM iocs WHERE session_id=? AND ioc_type=? AND ioc_value=?",
        (session_id, ioc_type, ioc_value)
    )
    if cur.fetchone():
        conn.close()
        return
    cur.execute("""
        INSERT INTO iocs
            (session_id, ioc_type, ioc_value, yara_rule, suricata_rule, extracted_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (session_id, ioc_type, ioc_value,
          yara_rule, suricata_rule,
          datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()


# ── Main Extraction Pipeline ──────────────────────────────────────────────────
def run_extraction() -> list:
    """
    Scan all unprocessed sessions and extract IoCs.
    Returns list of extracted IoC dicts.
    """
    init_ioc_table()

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur  = conn.cursor()
    # Process SUSPICIOUS and HIGHLY_SUSPICIOUS sessions
    cur.execute("""
        SELECT id, payload_raw, commands, src_ip
        FROM attacks
        WHERE risk_label IN ('SUSPICIOUS', 'HIGHLY_SUSPICIOUS')
    """)
    sessions = [dict(r) for r in cur.fetchall()]
    conn.close()

    all_iocs = []

    for session in sessions:
        sid     = session["id"]
        payload = (session.get("payload_raw") or "") + "\n" + (session.get("commands") or "")

        # Always add the source IP as an IoC
        src_ip = session.get("src_ip", "")
        if src_ip and not src_ip.startswith(("127.", "10.", "192.168.")):
            iocs = [("ip", src_ip)] + extract_iocs_from_payload(payload)
        else:
            iocs = extract_iocs_from_payload(payload)

        for ioc_type, ioc_value in iocs:
            yara_rule     = generate_yara_rule(ioc_type, ioc_value, sid)
            suricata_rule = generate_suricata_rule(ioc_type, ioc_value, sid)
            store_ioc(sid, ioc_type, ioc_value, yara_rule, suricata_rule)
            logger.info("IoC extracted  session=#%d  type=%s  value=%s",
                        sid, ioc_type, ioc_value)
            all_iocs.append({
                "session_id"   : sid,
                "ioc_type"     : ioc_type,
                "ioc_value"    : ioc_value,
                "yara_rule"    : yara_rule,
                "suricata_rule": suricata_rule
            })

    logger.info("Extraction complete. Total IoCs found: %d", len(all_iocs))
    return all_iocs


if __name__ == "__main__":
    run_extraction()
