"""
decoy_orchestrator.py - Neuro-Trap Decoy Orchestration Controller
Module 4: Monitors ML output in SQLite; spawns additional simulated
          decoy services on secondary ports when a session is classified
          as HIGHLY_SUSPICIOUS to maximise attacker dwell time.
"""

import sqlite3
import subprocess
import threading
import socket
import logging
import time
from datetime import datetime

# ── Configuration ─────────────────────────────────────────────────────────────
DB_PATH      = "neuro_trap.db"
POLL_INTERVAL = 10   # seconds between DB polls

# Secondary decoy ports to spawn when HIGHLY_SUSPICIOUS is detected
DECOY_PORTS = [21, 23, 3306, 5900, 8080]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [ORCHESTRATOR] %(message)s"
)
logger = logging.getLogger(__name__)

# Track which ports are already running so we don't double-spawn
_active_decoys: dict = {}   # port -> threading.Thread


# ── DB Helpers ────────────────────────────────────────────────────────────────
def init_decoy_table():
    """Create decoy_events table to log every spawn action."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS decoy_events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id  INTEGER NOT NULL,
            port        INTEGER NOT NULL,
            spawned_at  TEXT    NOT NULL,
            stopped_at  TEXT
        )
    """)
    conn.commit()
    conn.close()


def log_decoy_event(session_id: int, port: int):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO decoy_events (session_id, port, spawned_at) VALUES (?,?,?)",
        (session_id, port, datetime.utcnow().isoformat())
    )
    conn.commit()
    conn.close()


def get_highly_suspicious_sessions() -> list:
    """Return sessions flagged HIGHLY_SUSPICIOUS that have not yet triggered a decoy."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur  = conn.cursor()
    cur.execute("""
        SELECT a.id, a.src_ip
        FROM   attacks a
        WHERE  a.risk_label = 'HIGHLY_SUSPICIOUS'
          AND  a.id NOT IN (SELECT session_id FROM decoy_events)
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


# ── Simulated Decoy Service ────────────────────────────────────────────────────
# All responses are pre-configured strings — no attacker input is ever executed.

DECOY_BANNERS = {
    21  : b"220 FTP server ready\r\n",
    23  : b"\xff\xfd\x03\xff\xfb\x18Welcome to Telnet service\r\n",
    3306: b"\x4a\x00\x00\x00\x0a5.7.38-log\x00\x01\x00\x00\x00",
    5900: b"RFB 003.008\n",
    8080: (b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
           b"<html><body>Admin Panel</body></html>"),
}


def run_decoy_listener(port: int, stop_event: threading.Event):
    """
    Lightweight decoy listener on a given port.
    Sends a fake banner, logs data received, then closes the connection.
    Runs until stop_event is set.
    """
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", port))
        srv.listen(10)
        srv.settimeout(2.0)
        logger.info("Decoy service started on port %d", port)

        while not stop_event.is_set():
            try:
                client, addr = srv.accept()
                logger.info("Decoy port %d — connection from %s:%d", port, *addr)
                banner = DECOY_BANNERS.get(port, b"Service ready\r\n")
                try:
                    client.sendall(banner)
                    client.settimeout(15)
                    data = client.recv(1024)
                    if data:
                        logger.info("Decoy port %d — received %d bytes from %s",
                                    port, len(data), addr[0])
                except Exception:
                    pass
                finally:
                    client.close()
            except socket.timeout:
                continue

        srv.close()
        logger.info("Decoy service on port %d stopped.", port)

    except OSError as exc:
        logger.error("Cannot bind decoy on port %d: %s", port, exc)


# ── Spawn / Stop Decoys ────────────────────────────────────────────────────────
def spawn_decoys(session_id: int):
    """Spawn all configured decoy ports for a HIGHLY_SUSPICIOUS session."""
    for port in DECOY_PORTS:
        if port in _active_decoys:
            logger.info("Decoy port %d already active, skipping.", port)
            continue

        stop_evt = threading.Event()
        t = threading.Thread(
            target=run_decoy_listener,
            args=(port, stop_evt),
            daemon=True
        )
        t.start()
        _active_decoys[port] = (t, stop_evt)
        log_decoy_event(session_id, port)
        logger.info("Spawned decoy for session #%d on port %d", session_id, port)


def stop_all_decoys():
    """Signal all running decoy threads to stop."""
    for port, (t, stop_evt) in _active_decoys.items():
        stop_evt.set()
        t.join(timeout=5)
        logger.info("Stopped decoy on port %d", port)
    _active_decoys.clear()


# ── Main Monitoring Loop ───────────────────────────────────────────────────────
def run_orchestrator():
    """
    Poll the database every POLL_INTERVAL seconds.
    Spawn decoys whenever a new HIGHLY_SUSPICIOUS session is found.
    """
    init_decoy_table()
    logger.info("Decoy orchestrator running. Poll interval: %ds", POLL_INTERVAL)

    try:
        while True:
            sessions = get_highly_suspicious_sessions()
            for session in sessions:
                logger.info("HIGHLY_SUSPICIOUS session detected: #%d  src=%s",
                            session["id"], session["src_ip"])
                spawn_decoys(session["id"])
            time.sleep(POLL_INTERVAL)
    except KeyboardInterrupt:
        logger.info("Orchestrator shutting down.")
        stop_all_decoys()


if __name__ == "__main__":
    run_orchestrator()
