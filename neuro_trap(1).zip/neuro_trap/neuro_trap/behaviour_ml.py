"""
behaviour_ml.py - Neuro-Trap ML Analysis Engine
Module 2: Extracts behavioural features from captured sessions and
          classifies them using Isolation Forest anomaly detection.
          Labels: NORMAL | SUSPICIOUS | HIGHLY_SUSPICIOUS
"""

import sqlite3
import logging
import numpy as np
from datetime import datetime

from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# ── Configuration ─────────────────────────────────────────────────────────────
DB_PATH = "neuro_trap.db"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [ML ENGINE] %(message)s"
)
logger = logging.getLogger(__name__)

# ── Keywords ──────────────────────────────────────────────────────────────────
HIGHLY_KEYWORDS = [
    "wget", "curl", "/bin/bash", "/bin/sh", "nc -e", "ncat",
    "base64", "chmod +x", "cat /etc/shadow", "python -c",
    "perl -e", "ruby -e", "malware", "exploit", "4444", "shell.sh"
]
SUSPICIOUS_KEYWORDS = [
    "cat /etc/passwd", "whoami", "uname -a", "ifconfig",
    "netstat", "ps aux", "ls -la"
]


# ── Feature Extraction ────────────────────────────────────────────────────────
def extract_features(row: dict) -> list:
    commands_raw  = row.get("commands", "") or ""
    payload_raw   = row.get("payload_raw", "") or ""
    commands_list = [c for c in commands_raw.split("\n") if c.strip()]

    duration    = float(row.get("duration_sec", 0) or 0)
    bytes_recv  = int(row.get("bytes_recv", 0) or 0)
    cmd_count   = len(commands_list)
    unique_cmds = len(set(commands_list))
    avg_len     = (sum(len(c) for c in commands_list) / cmd_count
                   if cmd_count > 0 else 0.0)

    payload_lower = payload_raw.lower()
    has_exploit = int(any(kw in payload_lower for kw in HIGHLY_KEYWORDS))
    has_recon   = int(any(kw in payload_lower for kw in SUSPICIOUS_KEYWORDS))

    try:
        hour = datetime.fromisoformat(row.get("timestamp", "")).hour
    except Exception:
        hour = 0

    return [duration, bytes_recv, cmd_count, unique_cmds,
            avg_len, has_exploit, has_recon, hour]


# ── DB Helpers ────────────────────────────────────────────────────────────────
def load_all_sessions() -> list:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = [dict(r) for r in conn.execute("SELECT * FROM attacks").fetchall()]
    conn.close()
    return rows


def update_session_score(session_id: int, score: float, label: str):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "UPDATE attacks SET ml_score=?, risk_label=? WHERE id=?",
        (round(score, 4), label, session_id)
    )
    conn.commit()
    conn.close()


# ── Rule-based Classifier ─────────────────────────────────────────────────────
def classify_by_rules(row: dict) -> str | None:
    """
    Returns a label if keywords match, else None (fall through to ML).
    Priority: HIGHLY > SUSPICIOUS > None
    """
    payload = ((row.get("payload_raw") or "") + " " + (row.get("commands") or "")).lower()
    bytes_recv = int(row.get("bytes_recv", 0) or 0)

    # No data sent at all → definitely NORMAL (just banner grab)
    if bytes_recv == 0 and not payload.strip():
        return "NORMAL"

    if any(kw in payload for kw in HIGHLY_KEYWORDS):
        return "HIGHLY_SUSPICIOUS"

    if any(kw in payload for kw in SUSPICIOUS_KEYWORDS):
        return "SUSPICIOUS"

    return None   # let ML decide


# ── Main Analysis Pipeline ────────────────────────────────────────────────────
def run_ml_analysis() -> list:
    all_sessions = load_all_sessions()

    if len(all_sessions) < 5:
        logger.warning("Not enough sessions (%d). Need at least 5.", len(all_sessions))
        return []

    # First pass: apply rule-based labels immediately
    rule_results = []
    ml_candidates = []

    for row in all_sessions:
        rule_label = classify_by_rules(row)
        if rule_label is not None:
            score = -0.5 if rule_label == "HIGHLY_SUSPICIOUS" else \
                    -0.15 if rule_label == "SUSPICIOUS" else 0.2
            update_session_score(row["id"], score, rule_label)
            rule_results.append({"id": row["id"], "score": score, "label": rule_label})
        else:
            ml_candidates.append(row)

    logger.info("Rule-based: %d sessions labelled.", len(rule_results))

    # Second pass: ML on remaining sessions
    if ml_candidates:
        X_all    = np.array([extract_features(r) for r in all_sessions], dtype=float)
        X_cands  = np.array([extract_features(r) for r in ml_candidates], dtype=float)

        scaler   = StandardScaler()
        X_scaled = scaler.fit_transform(X_all)
        X_new    = scaler.transform(X_cands)

        model = IsolationForest(
            n_estimators=200,
            contamination=0.15,
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_scaled)
        scores = model.decision_function(X_new)

        ml_results = []
        for row, score in zip(ml_candidates, scores):
            if score < -0.20:
                label = "HIGHLY_SUSPICIOUS"
            elif score < 0.0:
                label = "SUSPICIOUS"
            else:
                label = "NORMAL"
            update_session_score(row["id"], float(score), label)
            logger.info("Session #%d  score=%.4f  label=%s", row["id"], score, label)
            ml_results.append({"id": row["id"], "score": float(score), "label": label})

        logger.info("ML: %d sessions scored.", len(ml_results))
        return rule_results + ml_results

    return rule_results


if __name__ == "__main__":
    run_ml_analysis()